# Solana Sovereign

Solana Sovereign is a regulated DeFi Prime Brokerage framework using:

- Noir (ZK circuits)
- Anchor (Solana programs)
- Next.js (Frontend)

## Prerequisites

### 1. Install Solana CLI
```bash
sh -c "$(curl -sSfL https://release.solana.com/stable/install)"
solana --version
```

### 2. Install Anchor
```bash
cargo install --git https://github.com/coral-xyz/anchor anchor-cli --locked
anchor --version
```

### 3. Install Noir (Nargo)
```bash
curl -L https://raw.githubusercontent.com/noir-lang/noirup/main/install | bash
noirup
nargo --version
```

## Compile Noir Circuit
```bash
cd circuits
nargo compile
```

## Build Anchor Programs
```bash
anchor build
anchor deploy --provider.cluster devnet
```

## Run Frontend
```bash
cd app
npm install
npm run dev
```

## Architecture Overview

- `/circuits`: ZK proof for age >= 18
- `/programs/sovereign_hub`: Issues Sovereign Pass after proof verification
- `/programs/gated_vault`: Allows deposits only if pass is valid
- `/app`: Next.js frontend to generate proof and submit transactions