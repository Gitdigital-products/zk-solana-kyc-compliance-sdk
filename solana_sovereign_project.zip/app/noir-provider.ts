import { Noir } from '@noir-lang/noir_js';
import circuit from '../circuits/target/circuit.json';

export async function generateProof(birthYear: number, currentYear: number) {
  const noir = new Noir(circuit);
  const input = {
    birth_year: birthYear,
    current_year: currentYear,
  };

  const { proof, publicInputs } = await noir.generateFinalProof(input);
  return { proof, publicInputs };
}