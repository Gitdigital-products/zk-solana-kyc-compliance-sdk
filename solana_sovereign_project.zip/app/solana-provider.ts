import { Connection, PublicKey, Transaction } from '@solana/web3.js';
import { Program, AnchorProvider, web3 } from '@project-serum/anchor';
import idl from '../idl/sovereign_hub.json';

export async function submitProofAndDeposit(
  wallet: any,
  proofValid: boolean,
  amount: number
) {
  const connection = new Connection('https://api.devnet.solana.com');
  const provider = new AnchorProvider(connection, wallet, {});
  const programId = new PublicKey(idl.metadata.address);
  const program = new Program(idl as any, programId, provider);

  const [passPda] = await PublicKey.findProgramAddress(
    [Buffer.from('sovereign_pass'), wallet.publicKey.toBuffer()],
    program.programId
  );

  await program.methods
    .verifyAndIssuePass(proofValid)
    .accounts({
      sovereignPass: passPda,
      user: wallet.publicKey,
      systemProgram: web3.SystemProgram.programId,
    })
    .rpc();

  console.log('Proof verified and Sovereign Pass issued.');

  // Deposit logic would call gated_vault program here
}