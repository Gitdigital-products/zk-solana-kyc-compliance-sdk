use anchor_lang::prelude::*;
use sovereign_hub::SovereignPass;

declare_id!("GaTeDVaUlT11111111111111111111111111111111");

#[program]
pub mod gated_vault {
    use super::*;

    pub fn deposit(ctx: Context<Deposit>, amount: u64) -> Result<()> {
        require!(ctx.accounts.sovereign_pass.valid, VaultError::InvalidPass);

        // Logic for handling deposit (simplified placeholder)
        msg!("Deposit of {} accepted.", amount);

        Ok(())
    }
}

#[derive(Accounts)]
pub struct Deposit<'info> {
    #[account(
        seeds = [b"sovereign_pass", user.key().as_ref()],
        bump
    )]
    pub sovereign_pass: Account<'info, SovereignPass>,

    #[account(mut)]
    pub user: Signer<'info>,
}

#[error_code]
pub enum VaultError {
    #[msg("Sovereign pass not valid")]
    InvalidPass,
}