use anchor_lang::prelude::*;

declare_id!("SoVeReiGn111111111111111111111111111111111");

#[program]
pub mod sovereign_hub {
    use super::*;

    pub fn verify_and_issue_pass(ctx: Context<VerifyAndIssuePass>, proof_valid: bool) -> Result<()> {
        require!(proof_valid, SovereignError::InvalidProof);

        let pass = &mut ctx.accounts.sovereign_pass;
        pass.owner = ctx.accounts.user.key();
        pass.valid = true;

        Ok(())
    }
}

#[derive(Accounts)]
pub struct VerifyAndIssuePass<'info> {
    #[account(
        init_if_needed,
        payer = user,
        space = 8 + 32 + 1,
        seeds = [b"sovereign_pass", user.key().as_ref()],
        bump
    )]
    pub sovereign_pass: Account<'info, SovereignPass>,

    #[account(mut)]
    pub user: Signer<'info>,

    pub system_program: Program<'info, System>,
}

#[account]
pub struct SovereignPass {
    pub owner: Pubkey,
    pub valid: bool,
}

#[error_code]
pub enum SovereignError {
    #[msg("Invalid ZK proof")]
    InvalidProof,
}