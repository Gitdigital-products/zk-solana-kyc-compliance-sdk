//! Anchor Instruction Definitions
//!
//! This module provides modernized instruction handling using the Anchor framework
//! to ensure safer and more structured program calls.
//!
//! ## Overview
//!
//! The instruction module defines all program instructions using Anchor's
//! type-safe IDL specifications, including:
//! - Instruction context structs
//! - Account validation constraints
//! - Event definitions
//! - Error codes
//!
//! ## Instructions
//!
//! - `create_kyc_account` - Create a new KYC account
//! - `update_kyc_status` - Update KYC status
//! - `verify_compliance` - Verify compliance for transfer
//! - `create_attestation` - Create compliance attestation
//! - `revoke_attestation` - Revoke attestation
//! - `register_asset` - Register RWA asset
//! - `update_compliance` - Update compliance requirements
//!
//! ## Usage
//!
//! ```rust
//! use kyc_compliance::instructions::{*, self};
//! ```

use anchor_lang::prelude::*;
use anchor_lang::solana_program::system_program;

/// Program ID
declare_id!("KYCCom1111111111111111111111111111111");

/// KYC Account PDA seeds
pub const KYC_ACCOUNT_SEED: &[u8] = b"kyc_account";

/// Attestation PDA seeds
pub const ATTESTATION_SEED: &[u8] = b"attestation";

/// Asset PDA seeds
pub const ASSET_SEED: &[u8] = b"rwa_asset";

/// Create KYC Account instruction
/// Creates a new KYC account for a wallet
#[derive(Accounts)]
pub struct CreateKycAccount<'info> {
    /// Payer for account creation
    #[account(mut, signer)]
    pub payer: Signer<'info>,

    /// New KYC account
    #[account(
        init,
        payer = payer,
        space = 8 + KYCAccount::INIT_SPACE,
        seeds = [KYC_ACCOUNT_SEED, payer.key().as_ref()],
        bump
    )]
    pub kyc_account: Account<'info, KycAccount>,

    /// System program
    #[account(address = system_program::ID)]
    pub system_program: Program<'info, System>,
}

/// Update KYC Status instruction
/// Updates the KYC status for an existing account
#[derive(Accounts)]
#[instruction(new_level: u8)]
pub struct UpdateKycStatus<'info> {
    /// Authority that can update status
    #[account(mut, signer)]
    pub authority: Signer<'info>,

    /// KYC account to update
    #[account(
        mut,
        seeds = [KYC_ACCOUNT_SEED, wallet.key().as_ref()],
        bump,
        has_one = authority
    )]
    pub kyc_account: Account<'info, KycAccount>,

    /// Wallet address
    pub wallet: Account<'info, WalletAccount>,
}

/// Verify Compliance instruction
/// Verifies compliance for a token transfer
#[derive(Accounts)]
pub struct VerifyCompliance<'info> {
    /// Program authority
    #[account(signer)]
    pub authority: Signer<'info>,

    /// KYC account of sender
    #[account(
        seeds = [KYC_ACCOUNT_SEED, sender.key().as_ref()],
        bump
    )]
    pub sender_kyc: Account<'info, KycAccount>,

    /// KYC account of recipient
    #[account(
        seeds = [KYC_ACCOUNT_SEED, recipient.key().as_ref()],
        bump
    )]
    pub recipient_kyc: Option<Account<'info, KycAccount>>,

    /// Sender wallet
    pub sender: Account<'info, WalletAccount>,

    /// Recipient wallet
    pub recipient: Account<'info, WalletAccount>,

    /// Asset info
    pub asset: Account<'info, AssetAccount>,
}

/// Create Attestation instruction
/// Creates a compliance attestation for a wallet
#[derive(Accounts)]
pub struct CreateAttestation<'info> {
    /// Attestation authority
    #[account(signer)]
    pub authority: Signer<'info>,

    /// New attestation account
    #[account(
        init,
        payer = authority,
        space = 8 + Attestation::INIT_SPACE,
        seeds = [ATTESTATION_SEED, wallet.key().as_ref(), authority.key().as_ref()],
        bump
    )]
    pub attestation: Account<'info, Attestation>,

    /// Wallet being attested
    pub wallet: Account<'info, WalletAccount>,

    /// System program
    #[account(address = system_program::ID)]
    pub system_program: Program<'info, System>,
}

/// Revoke Attestation instruction
/// Revokes an existing attestation
#[derive(Accounts)]
pub struct RevokeAttestation<'info> {
    /// Attestation authority
    #[account(mut, signer)]
    pub authority: Signer<'info>,

    /// Attestation to revoke
    #[account(
        mut,
        seeds = [ATTESTATION_SEED, wallet.key().as_ref(), authority.key().as_ref()],
        bump,
        has_one = authority
    )]
    pub attestation: Account<'info, Attestation>,

    /// Wallet
    pub wallet: Account<'info, WalletAccount>,
}

/// Register Asset instruction
/// Registers a new RWA asset with compliance requirements
#[derive(Accounts)]
pub struct RegisterAsset<'info> {
    /// Asset issuer
    #[account(signer)]
    pub issuer: Signer<'info>,

    /// New asset account
    #[account(
        init,
        payer = issuer,
        space = 8 + Asset::INIT_SPACE,
        seeds = [ASSET_SEED, mint.key().as_ref()],
        bump
    )]
    pub asset: Account<'info, Asset>,

    /// Token mint
    pub mint: Account<'info, Mint>,

    /// System program
    #[account(address = system_program::ID)]
    pub system_program: Program<'info, System>,

    /// Token program
    pub token_program: Program<'info, Token>,
}

/// Update Compliance Requirements instruction
/// Updates compliance requirements for an asset
#[derive(Accounts)]
pub struct UpdateCompliance<'info> {
    /// Asset issuer
    #[account(mut, signer)]
    pub issuer: Signer<'info>,

    /// Asset to update
    #[account(
        mut,
        seeds = [ASSET_SEED, asset.mint.as_ref()],
        bump,
        has_one = issuer
    )]
    pub asset: Account<'info, Asset>,
}

/// Emergency Freeze instruction
/// Triggers emergency freeze via circuit breaker
#[derive(Accounts)]
pub struct EmergencyFreeze<'info> {
    /// Circuit breaker authority
    #[account(signer)]
    pub authority: Signer<'info>,

    /// Circuit breaker state
    #[account(
        mut,
        seeds = [b"circuit_breaker"],
        bump
    )]
    pub circuit_breaker: Account<'info, CircuitBreaker>,
}

/// Resume Operations instruction
/// Resumes operations after emergency freeze
#[derive(Accounts)]
pub struct ResumeOperations<'info> {
    /// Circuit breaker authority
    #[account(signer)]
    pub authority: Signer<'info>,

    /// Circuit breaker state
    #[account(
        mut,
        seeds = [b"circuit_breaker"],
        bump
    )]
    pub circuit_breaker: Account<'info, CircuitBreaker>,
}

/// Batch Verify instruction
/// Verifies multiple wallets in a single transaction
#[derive(Accounts)]
pub struct BatchVerify<'info> {
    /// Verifier authority
    #[account(signer)]
    pub authority: Signer<'info>,

    /// Verification result account
    #[account(
        init,
        payer = authority,
        space = 8 + BatchResult::INIT_SPACE,
        seeds = [b"batch_result", authority.key().as_ref()],
        bump
    )]
    pub result: Account<'info, BatchResult>,
}

// ============== Account Types ==============

/// KYC Account
#[account]
#[derive(InitSpace)]
pub struct KycAccount {
    /// Owner of the KYC account
    pub owner: Pubkey,

    /// KYC verification level
    pub level: u8,

    /// Status
    pub status: KycStatus,

    /// Provider
    pub provider: Pubkey,

    /// Expiration timestamp
    pub expires_at: i64,

    /// Creation timestamp
    pub created_at: i64,

    /// Last update timestamp
    pub updated_at: i64,

    /// Metadata
    pub metadata: Vec<u8>,
}

/// KYC Status
#[derive(AnchorSerialize, AnchorDeserialize, Clone, Copy, PartialEq, Eq)]
pub enum KycStatus {
    /// Not verified
    Unverified,
    /// Pending verification
    Pending,
    /// Verified
    Verified,
    /// Suspended
    Suspended,
    /// Revoked
    Revoked,
}

impl Default for KycStatus {
    fn default() -> Self {
        KycStatus::Unverified
    }
}

/// Wallet Account (for reference)
#[account]
#[derive(InitSpace)]
pub struct WalletAccount {
    /// Wallet address
    pub wallet: Pubkey,
}

/// Asset Account
#[account]
#[derive(InitSpace)]
pub struct AssetAccount {
    /// Asset ID
    pub asset_id: Pubkey,

    /// Mint
    pub mint: Pubkey,
}

/// Attestation
#[account]
#[derive(InitSpace)]
pub struct Attestation {
    /// Wallet being attested
    pub wallet: Pubkey,

    /// Attesting authority
    pub authority: Pubkey,

    /// KYC level
    pub level: u8,

    /// Status
    pub status: AttestationStatus,

    /// Expiration timestamp
    pub expires_at: i64,

    /// Creation timestamp
    pub created_at: i64,

    /// Revoked flag
    pub revoked: bool,
}

/// Attestation Status
#[derive(AnchorSerialize, AnchorDeserialize, Clone, Copy, PartialEq, Eq)]
pub enum AttestationStatus {
    /// Pending
    Pending,
    /// Active
    Active,
    /// Revoked
    Revoked,
}

impl Default for AttestationStatus {
    fn default() -> Self {
        AttestationStatus::Pending
    }
}

/// Asset
#[account]
#[derive(InitSpace)]
pub struct Asset {
    /// Asset ID
    pub asset_id: Pubkey,

    /// Issuer
    pub issuer: Pubkey,

    /// Mint
    pub mint: Pubkey,

    /// Asset name
    pub name: String,

    /// Asset symbol
    pub symbol: String,

    /// Total supply
    pub total_supply: u64,

    /// Compliance requirements
    pub compliance: ComplianceData,

    /// Active flag
    pub is_active: bool,

    /// Created at
    pub created_at: i64,

    /// Updated at
    pub updated_at: i64,
}

/// Compliance Data
#[derive(AnchorSerialize, AnchorDeserialize, Clone, Debug)]
#[derive(InitSpace)]
pub struct ComplianceData {
    /// Required KYC level
    pub required_kyc_level: u8,

    /// Required accreditation
    pub required_accreditation: u8,

    /// Allowed countries
    pub allowed_countries: Vec<String>,

    /// Blocked countries
    pub blocked_countries: Vec<String>,

    /// Min investment
    pub min_investment: u64,

    /// Max investment
    pub max_investment: u64,

    /// Transfer restrictions enabled
    pub transfer_restrictions: bool,
}

/// Circuit Breaker
#[account]
#[derive(InitSpace)]
pub struct CircuitBreaker {
    /// Whether frozen
    pub is_frozen: bool,

    /// Freeze reason
    pub reason: String,

    /// Last freeze timestamp
    pub last_freeze: i64,

    /// Cooldown end timestamp
    pub cooldown_end: i64,

    /// Authority
    pub authority: Pubkey,
}

/// Batch Result
#[account]
#[derive(InitSpace)]
pub struct BatchResult {
    /// Authority
    pub authority: Pubkey,

    /// Total verified
    pub total: u32,

    /// Valid count
    pub valid: u32,

    /// Invalid count
    pub invalid: u32,

    /// Timestamp
    pub timestamp: i64,

    /// Results
    pub results: Vec<VerificationEntry>,
}

/// Verification Entry
#[derive(AnchorSerialize, AnchorDeserialize, Clone, Debug)]
#[derive(InitSpace)]
pub struct VerificationEntry {
    /// Wallet
    pub wallet: Pubkey,

    /// Valid
    pub valid: bool,

    /// Reason if invalid
    pub reason: Option<String>,
}

// ============== Events ==============

/// KYC Account Created event
#[event]
pub struct KycAccountCreated {
    /// Owner
    pub owner: Pubkey,
    /// Level
    pub level: u8,
    /// Provider
    pub provider: Pubkey,
    /// Timestamp
    pub timestamp: i64,
}

/// KYC Status Updated event
#[event]
pub struct KycStatusUpdated {
    /// Owner
    pub owner: Pubkey,
    /// Old status
    pub old_status: KycStatus,
    /// New status
    pub new_status: KycStatus,
    /// Timestamp
    pub timestamp: i64,
}

/// Compliance Verified event
#[event]
pub struct ComplianceVerified {
    /// Sender
    pub sender: Pubkey,
    /// Recipient
    pub recipient: Pubkey,
    /// Valid
    pub valid: bool,
    /// Reason if invalid
    pub reason: Option<String>,
    /// Timestamp
    pub timestamp: i64,
}

/// Attestation Created event
#[event]
pub struct AttestationCreated {
    /// Wallet
    pub wallet: Pubkey,
    /// Authority
    pub authority: Pubkey,
    /// Level
    pub level: u8,
    /// Expires at
    pub expires_at: i64,
    /// Timestamp
    pub timestamp: i64,
}

/// Attestation Revoked event
#[event]
pub struct AttestationRevoked {
    /// Wallet
    pub wallet: Pubkey,
    /// Authority
    pub authority: Pubkey,
    /// Reason
    pub reason: String,
    /// Timestamp
    pub timestamp: i64,
}

/// Asset Registered event
#[event]
pub struct AssetRegistered {
    /// Asset ID
    pub asset_id: Pubkey,
    /// Issuer
    pub issuer: Pubkey,
    /// Name
    pub name: String,
    /// Symbol
    pub symbol: String,
    /// Timestamp
    pub timestamp: i64,
}

/// Emergency Freeze event
#[event]
pub struct EmergencyFreezeEvent {
    /// Authority
    pub authority: Pubkey,
    /// Reason
    pub reason: String,
    /// Timestamp
    pub timestamp: i64,
}

/// Operations Resumed event
#[event]
pub struct OperationsResumedEvent {
    /// Authority
    pub authority: Pubkey,
    /// Timestamp
    pub timestamp: i64,
}

// ============== Errors ==============

/// Custom errors
#[error_code]
pub enum KycError {
    #[msg("KYC account not found")]
    AccountNotFound,

    #[msg("Invalid KYC level")]
    InvalidKycLevel,

    #[msg("KYC expired")]
    KycExpired,

    #[msg("KYC suspended")]
    KycSuspended,

    #[msg("Insufficient KYC level")]
    InsufficientKycLevel,

    #[msg("Provider not authorized")]
    UnauthorizedProvider,

    #[msg("Transfer not allowed")]
    TransferNotAllowed,

    #[msg("Compliance verification failed")]
    ComplianceVerificationFailed,

    #[msg("Attestation not found")]
    AttestationNotFound,

    #[msg("Attestation expired")]
    AttestationExpired,

    #[msg("Asset not found")]
    AssetNotFound,

    #[msg("Asset not active")]
    AssetNotActive,

    #[msg("Invalid compliance requirements")]
    InvalidCompliance,

    #[msg("Geographic restriction")]
    GeographicRestriction,

    #[msg("Investment limit exceeded")]
    InvestmentLimitExceeded,

    #[msg("Circuit breaker is frozen")]
    CircuitBreakerFrozen,

    #[msg("Cooldown period active")]
    CooldownActive,

    #[msg("Unauthorized")]
    Unauthorized,

    #[msg("Invalid signature")]
    InvalidSignature,

    #[msg("Already initialized")]
    AlreadyInitialized,
}

// ============== Instruction Handlers ==============

/// Create KYC Account handler
pub fn create_kyc_account(
    ctx: Context<CreateKycAccount>,
    level: u8,
    provider: Pubkey,
    validity_duration: i64,
) -> Result<()> {
    let kyc_account = &mut ctx.accounts.kyc_account;
    let clock = Clock::get()?;

    kyc_account.owner = ctx.accounts.payer.key();
    kyc_account.level = level;
    kyc_account.status = KycStatus::Verified;
    kyc_account.provider = provider;
    kyc_account.expires_at = clock.unix_timestamp + validity_duration;
    kyc_account.created_at = clock.unix_timestamp;
    kyc_account.updated_at = clock.unix_timestamp;
    kyc_account.metadata = vec![];

    emit!(KycAccountCreated {
        owner: kyc_account.owner,
        level: kyc_account.level,
        provider: kyc_account.provider,
        timestamp: clock.unix_timestamp,
    });

    Ok(())
}

/// Update KYC Status handler
pub fn update_kyc_status(
    ctx: Context<UpdateKycStatus>,
    new_status: KycStatus,
    new_level: Option<u8>,
) -> Result<()> {
    let kyc_account = &mut ctx.accounts.kyc_account;
    let old_status = kyc_account.status;
    let clock = Clock::get()?;

    kyc_account.status = new_status;
    if let Some(level) = new_level {
        kyc_account.level = level;
    }
    kyc_account.updated_at = clock.unix_timestamp;

    emit!(KycStatusUpdated {
        owner: kyc_account.owner,
        old_status,
        new_status: kyc_account.status,
        timestamp: clock.unix_timestamp,
    });

    Ok(())
}

/// Verify Compliance handler
pub fn verify_compliance(
    ctx: Context<VerifyCompliance>,
    amount: u64,
) -> Result<bool> {
    let sender_kyc = &ctx.accounts.sender_kyc;
    let clock = Clock::get()?;

    // Check KYC is valid
    if sender_kyc.status != KycStatus::Verified {
        emit!(ComplianceVerified {
            sender: ctx.accounts.sender.key(),
            recipient: ctx.accounts.recipient.key(),
            valid: false,
            reason: Some("Sender KYC not verified".to_string()),
            timestamp: clock.unix_timestamp,
        });
        return Ok(false);
    }

    // Check expiration
    if sender_kyc.expires_at < clock.unix_timestamp {
        emit!(ComplianceVerified {
            sender: ctx.accounts.sender.key(),
            recipient: ctx.accounts.recipient.key(),
            valid: false,
            reason: Some("KYC expired".to_string()),
            timestamp: clock.unix_timestamp,
        });
        return Ok(false);
    }

    emit!(ComplianceVerified {
        sender: ctx.accounts.sender.key(),
        recipient: ctx.accounts.recipient.key(),
        valid: true,
        reason: None,
        timestamp: clock.unix_timestamp,
    });

    Ok(true)
}

/// Create Attestation handler
pub fn create_attestation(
    ctx: Context<CreateAttestation>,
    level: u8,
    validity_duration: i64,
) -> Result<()> {
    let attestation = &mut ctx.accounts.attestation;
    let clock = Clock::get()?;

    attestation.wallet = ctx.accounts.wallet.key();
    attestation.authority = ctx.accounts.authority.key();
    attestation.level = level;
    attestation.status = AttestationStatus::Active;
    attestation.expires_at = clock.unix_timestamp + validity_duration;
    attestation.created_at = clock.unix_timestamp;
    attestation.revoked = false;

    emit!(AttestationCreated {
        wallet: attestation.wallet,
        authority: attestation.authority,
        level: attestation.level,
        expires_at: attestation.expires_at,
        timestamp: clock.unix_timestamp,
    });

    Ok(())
}

/// Revoke Attestation handler
pub fn revoke_attestation(
    ctx: Context<RevokeAttestation>,
    reason: String,
) -> Result<()> {
    let attestation = &mut ctx.accounts.attestation;
    let clock = Clock::get()?;

    attestation.status = AttestationStatus::Revoked;
    attestation.revoked = true;

    emit!(AttestationRevoked {
        wallet: attestation.wallet,
        authority: attestation.authority,
        reason: reason.clone(),
        timestamp: clock.unix_timestamp,
    });

    Ok(())
}

/// Register Asset handler
pub fn register_asset(
    ctx: Context<RegisterAsset>,
    name: String,
    symbol: String,
    total_supply: u64,
    required_kyc_level: u8,
    required_accreditation: u8,
    allowed_countries: Vec<String>,
    blocked_countries: Vec<String>,
    min_investment: u64,
    max_investment: u64,
    transfer_restrictions: bool,
) -> Result<()> {
    let asset = &mut ctx.accounts.asset;
    let clock = Clock::get()?;

    let asset_id = Pubkey::find_program_address(
        &[ASSET_SEED, ctx.accounts.mint.key().as_ref()],
        &ID,
    ).0;

    asset.asset_id = asset_id;
    asset.issuer = ctx.accounts.issuer.key();
    asset.mint = ctx.accounts.mint.key();
    asset.name = name.clone();
    asset.symbol = symbol.clone();
    asset.total_supply = total_supply;
    asset.compliance = ComplianceData {
        required_kyc_level,
        required_accreditation,
        allowed_countries,
        blocked_countries,
        min_investment,
        max_investment,
        transfer_restrictions,
    };
    asset.is_active = true;
    asset.created_at = clock.unix_timestamp;
    asset.updated_at = clock.unix_timestamp;

    emit!(AssetRegistered {
        asset_id,
        issuer: asset.issuer,
        name,
        symbol,
        timestamp: clock.unix_timestamp,
    });

    Ok(())
}

/// Emergency Freeze handler
pub fn emergency_freeze(
    ctx: Context<EmergencyFreeze>,
    reason: String,
) -> Result<()> {
    let circuit_breaker = &mut ctx.accounts.circuit_breaker;
    let clock = Clock::get()?;

    circuit_breaker.is_frozen = true;
    circuit_breaker.reason = reason.clone();
    circuit_breaker.last_freeze = clock.unix_timestamp;
    circuit_breaker.cooldown_end = clock.unix_timestamp + 3600; // 1 hour

    emit!(EmergencyFreezeEvent {
        authority: ctx.accounts.authority.key(),
        reason,
        timestamp: clock.unix_timestamp,
    });

    Ok(())
}

/// Resume Operations handler
pub fn resume_operations(
    ctx: Context<ResumeOperations>,
) -> Result<()> {
    let circuit_breaker = &mut ctx.accounts.circuit_breaker;
    let clock = Clock::get()?;

    // Check cooldown
    if clock.unix_timestamp < circuit_breaker.cooldown_end {
        return err!(KycError::CooldownActive);
    }

    circuit_breaker.is_frozen = false;
    circuit_breaker.reason = String::new();

    emit!(OperationsResumedEvent {
        authority: ctx.accounts.authority.key(),
        timestamp: clock.unix_timestamp,
    });

    Ok(())
}
