//! Circuit Breaker Program Module
//!
//! This module implements a multi-signature controlled emergency freeze mechanism
//! that can instantly halt token transfers across the protocol if a major threat
//! is detected. This is a critical security feature designed for institutional
//! deployments.
//!
//! ## Overview
//!
//! The circuit breaker allows authorized multi-signature guardians to pause
//! all compliance-related operations in case of:
//! - Security breaches
//! - Detected vulnerabilities
//! - Suspicious mass exfiltration
//! - Regulatory actions
//! - Emergency maintenance
//!
//! ## Security Model
//!
//! - Requires M-of-N signatures from authorized guardians
//! - All freeze/unfreeze actions are logged on-chain
//! - Time-locked cooldown period after emergency freeze
//! - Automatic resume after configurable timeout (optional)
//!
//! ## Usage
//!
//! ```rust
//! use kyc_compliance::security::circuit_breaker::{CircuitBreaker, SecurityConfig, FreezeReason};
//!
//! // Initialize circuit breaker
//! let cb = CircuitBreaker::new(config, guardians, threshold)?;
//!
//! // Emergency freeze (requires M signatures)
//! cb.emergency_freeze(ctx, FreezeReason::SecurityBreach, signatures)?;
//!
//! // Resume operations
//! cb.resume_operations(ctx, signatures)?;
//! ```

use solana_program::{
    account_info::AccountInfo,
    clock::Clock,
    entrypoint::ProgramResult,
    program_error::ProgramError,
    pubkey::Pubkey,
    sysvar::Sysvar,
};
use std::collections::HashMap;

/// Maximum number of guardians allowed
pub const MAX_GUARDIANS: usize = 24;

/// Minimum number of guardians required
pub const MIN_GUARDIANS: usize = 3;

/// Maximum freeze reason length
pub const MAX_REASON_LENGTH: usize = 256;

/// Default cooldown period in seconds (1 hour)
pub const DEFAULT_COOLDOWN_SECS: u64 = 3600;

/// Maximum cooldown period in seconds (30 days)
pub const MAX_COOLDOWN_SECS: u64 = 2592000;

/// Reasons for triggering the circuit breaker
#[derive(Debug, Clone, Copy, PartialEq, Eq, solana_program::borsh::BorshSerialize, solana_program::borsh::BorshDeserialize)]
pub enum FreezeReason {
    /// No reason specified
    None = 0,
    /// Security breach detected
    SecurityBreach = 1,
    /// Suspicious activity detected
    SuspiciousActivity = 2,
    /// Vulnerability discovered
    Vulnerability = 3,
    /// Regulatory action required
    RegulatoryAction = 4,
    /// Emergency maintenance
    EmergencyMaintenance = 5,
    /// Mass exfiltration attempt
    MassExfiltration = 6,
    /// Oracle failure
    OracleFailure = 7,
    /// Manual override by administrator
    ManualOverride = 8,
}

impl Default for FreezeReason {
    fn default() -> Self {
        FreezeReason::None
    }
}

impl FreezeReason {
    /// Get the human-readable description
    pub fn to_string(&self) -> &'static str {
        match self {
            FreezeReason::None => "None",
            FreezeReason::SecurityBreach => "Security Breach Detected",
            FreezeReason::SuspiciousActivity => "Suspicious Activity",
            FreezeReason::Vulnerability => "Vulnerability Discovered",
            FreezeReason::RegulatoryAction => "Regulatory Action Required",
            FreezeReason::EmergencyMaintenance => "Emergency Maintenance",
            FreezeReason::MassExfiltration => "Mass Exfiltration Attempt",
            FreezeReason::OracleFailure => "Oracle Failure",
            FreezeReason::ManualOverride => "Manual Administrator Override",
        }
    }

    /// Check if this reason requires immediate action
    pub fn is_critical(&self) -> bool {
        matches!(
            self,
            FreezeReason::SecurityBreach
                | FreezeReason::MassExfiltration
                | FreezeReason::Vulnerability
        )
    }
}

/// Status of the circuit breaker
#[derive(Debug, Clone, Copy, PartialEq, Eq, solana_program::borsh::BorshSerialize, solana_program::borsh::BorshDeserialize)]
pub enum CircuitBreakerStatus {
    /// Normal operations
    Operational = 0,
    /// Emergency freeze active
    Frozen = 1,
    /// Throttling mode (partial restrictions)
    Throttled = 2,
    /// Maintenance mode
    Maintenance = 3,
}

impl Default for CircuitBreakerStatus {
    fn default() -> Self {
        CircuitBreakerStatus::Operational
    }
}

/// Guardian signature information
#[derive(Debug, Clone, solana_program::borsh::BorshSerialize, solana_program::borsh::BorshDeserialize)]
pub struct GuardianSignature {
    /// Guardian public key
    pub guardian: Pubkey,
    /// Signature timestamp
    pub timestamp: i64,
    /// Signature bytes
    pub signature: [u8; 64],
}

/// Circuit breaker history entry
#[derive(Debug, Clone, solana_program::borsh::BorshSerialize, solana_program::borsh::BorshDeserialize)]
pub struct FreezeEvent {
    /// Reason for freeze
    pub reason: FreezeReason,
    /// Human-readable description
    pub description: String,
    /// Guardian who initiated
    pub initiator: Pubkey,
    /// Additional signers
    pub additional_signers: Vec<Pubkey>,
    /// Timestamp of freeze
    pub timestamp: i64,
    /// Block height at freeze
    pub block_height: u64,
    /// Whether operations were resumed
    pub resumed: bool,
    /// Timestamp of resume (if resumed)
    pub resume_timestamp: Option<i64>,
}

impl FreezeEvent {
    /// Create a new freeze event
    pub fn new(
        reason: FreezeReason,
        description: String,
        initiator: Pubkey,
        additional_signers: Vec<Pubkey>,
        timestamp: i64,
        block_height: u64,
    ) -> Self {
        Self {
            reason,
            description,
            initiator,
            additional_signers,
            timestamp,
            block_height,
            resumed: false,
            resume_timestamp: None,
        }
    }

    /// Mark the event as resumed
    pub fn mark_resumed(&mut self, timestamp: i64) {
        self.resumed = true;
        self.resume_timestamp = Some(timestamp);
    }
}

/// Security configuration for the circuit breaker
#[derive(Debug, Clone, solana_program::borsh::BorshSerialize, solana_program::borsh::BorshDeserialize)]
pub struct SecurityConfig {
    /// Circuit breaker status
    pub status: CircuitBreakerStatus,
    /// Guardian public keys
    pub guardians: Vec<Pubkey>,
    /// Required signature threshold (M-of-N)
    pub threshold: u8,
    /// Cooldown period in seconds after freeze
    pub cooldown_secs: u64,
    /// Time until automatic resume (0 = no auto-resume)
    pub auto_resume_secs: u64,
    /// Maximum freeze events to keep in history
    pub max_history: u8,
    /// Whether emergency actions are enabled
    pub emergency_enabled: bool,
    /// Reserved space
    pub reserved: [u8; 32],
}

impl SecurityConfig {
    /// Create a new security configuration
    pub fn new(guardians: Vec<Pubkey>, threshold: u8) -> Result<Self, ProgramError> {
        // Validate guardians
        if guardians.len() < MIN_GUARDIANS {
            return Err(ProgramError::Custom(0x2001)); // TooFewGuardians
        }

        if guardians.len() > MAX_GUARDIANS {
            return Err(ProgramError::Custom(0x2002)); // TooManyGuardians
        }

        // Validate threshold
        if threshold as usize > guardians.len() {
            return Err(ProgramError::Custom(0x2003)); // ThresholdExceedsGuardians
        }

        if threshold < 2 {
            return Err(ProgramError::Custom(0x2004)); // ThresholdTooLow
        }

        Ok(Self {
            status: CircuitBreakerStatus::Operational,
            guardians,
            threshold,
            cooldown_secs: DEFAULT_COOLDOWN_SECS,
            auto_resume_secs: 0,
            max_history: 100,
            emergency_enabled: true,
            reserved: [0u8; 32],
        })
    }

    /// Create a configuration with custom cooldown
    pub fn with_cooldown(mut self, cooldown_secs: u64) -> Result<Self, ProgramError> {
        if cooldown_secs > MAX_COOLDOWN_SECS {
            return Err(ProgramError::Custom(0x2005)); // CooldownTooLong
        }
        self.cooldown_secs = cooldown_secs;
        Ok(self)
    }

    /// Create a configuration with auto-resume
    pub fn with_auto_resume(mut self, auto_resume_secs: u64) -> Result<Self, ProgramError> {
        if auto_resume_secs > MAX_COOLDOWN_SECS {
            return Err(ProgramError::Custom(0x2005)); // CooldownTooLong
        }
        self.auto_resume_secs = auto_resume_secs;
        Ok(self)
    }

    /// Check if the circuit breaker is active
    pub fn is_active(&self) -> bool {
        self.status != CircuitBreakerStatus::Operational
    }

    /// Check if frozen
    pub fn is_frozen(&self) -> bool {
        self.status == CircuitBreakerStatus::Frozen
    }

    /// Check if throttled
    pub fn is_throttled(&self) -> bool {
        self.status == CircuitBreakerStatus::Throttled
    }

    /// Validate guardian count meets threshold
    pub fn validate_threshold(&self, signatures: &[Pubkey]) -> bool {
        signatures.iter().filter(|g| self.guardians.contains(g)).count() >= self.threshold as usize
    }

    /// Check if an address is a guardian
    pub fn is_guardian(&self, address: &Pubkey) -> bool {
        self.guardians.contains(address)
    }
}

/// Errors that can occur during circuit breaker operations
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CircuitBreakerError {
    /// Too few guardians configured
    TooFewGuardians = 0x2001,
    /// Too many guardians configured
    TooManyGuardians = 0x2002,
    /// Threshold exceeds number of guardians
    ThresholdExceedsGuardians = 0x2003,
    /// Threshold too low (minimum 2 required)
    ThresholdTooLow = 0x2004,
    /// Cooldown period too long
    CooldownTooLong = 0x2005,
    /// Circuit breaker not frozen
    NotFrozen = 0x2006,
    /// Already frozen
    AlreadyFrozen = 0x2007,
    /// Invalid guardian signature
    InvalidSignature = 0x2008,
    /// Insufficient signatures
    InsufficientSignatures = 0x2009,
    /// Cooldown period not elapsed
    CooldownActive = 0x200a,
    /// Unauthorized caller
    Unauthorized = 0x200b,
    /// Circuit breaker disabled
    Disabled = 0x200c,
    /// Invalid reason provided
    InvalidReason = 0x200d,
    /// History full
    HistoryFull = 0x200e,
}

impl From<CircuitBreakerError> for ProgramError {
    fn from(e: CircuitBreakerError) -> Self {
        ProgramError::Custom(e as u32)
    }
}

/// Circuit breaker implementation
pub struct CircuitBreaker;

impl CircuitBreaker {
    /// Emergency freeze the protocol
    ///
    /// Requires M-of-N guardian signatures to activate.
    ///
    /// # Arguments
    ///
    /// * `config` - Security configuration
    /// * `reason` - Reason for freeze
    /// * `description` - Human-readable description
    /// * `signers` - List of guardian signatures
    /// * `clock` - Clock for timestamp
    ///
    /// # Errors
    ///
    /// Returns error if insufficient signatures or invalid state
    pub fn emergency_freeze(
        config: &mut SecurityConfig,
        reason: FreezeReason,
        description: String,
        signers: &[Pubkey],
        clock: &Clock,
    ) -> Result<FreezeEvent, ProgramError> {
        // Check if already frozen
        if config.is_frozen() {
            return Err(CircuitBreakerError::AlreadyFrozen.into());
        }

        // Validate reason
        if reason == FreezeReason::None {
            return Err(CircuitBreakerError::InvalidReason.into());
        }

        // Validate threshold
        if !config.validate_threshold(signers) {
            return Err(CircuitBreakerError::InsufficientSignatures.into());
        }

        // Check emergency is enabled
        if !config.emergency_enabled {
            return Err(CircuitBreakerError::Disabled.into());
        }

        // Update status
        config.status = CircuitBreakerStatus::Frozen;

        // Create freeze event
        let initiator = signers[0];
        let additional_signers = signers[1..].to_vec();

        Ok(FreezeEvent::new(
            reason,
            description,
            initiator,
            additional_signers,
            clock.unix_timestamp,
            clock.slot,
        ))
    }

    /// Resume operations after a freeze
    ///
    /// Requires M-of-N guardian signatures to resume.
    ///
    /// # Arguments
    ///
    /// * `config` - Security configuration
    /// * `signers` - List of guardian signatures
    /// * `clock` - Clock for timestamp
    /// * `last_freeze` - Last freeze event
    ///
    /// # Errors
    ///
    /// Returns error if not frozen or insufficient signatures
    pub fn resume_operations(
        config: &mut SecurityConfig,
        signers: &[Pubkey],
        clock: &Clock,
        last_freeze: &FreezeEvent,
    ) -> Result<(), ProgramError> {
        // Check if frozen
        if !config.is_frozen() {
            return Err(CircuitBreakerError::NotFrozen.into());
        }

        // Validate threshold
        if !config.validate_threshold(signers) {
            return Err(CircuitBreakerError::InsufficientSignatures.into());
        }

        // Check cooldown
        let elapsed = clock.unix_timestamp.saturating_sub(last_freeze.timestamp);
        if elapsed < config.cooldown_secs as i64 {
            return Err(CircuitBreakerError::CooldownActive.into());
        }

        // Resume operations
        config.status = CircuitBreakerStatus::Operational;

        Ok(())
    }

    /// Enable throttling mode (partial restrictions)
    ///
    /// This allows for graduated response where only certain operations
    /// are restricted rather than a complete freeze.
    ///
    /// # Arguments
    ///
    /// * `config` - Security configuration
    /// * `signers` - List of guardian signatures
    /// * `reason` - Reason for throttling
    ///
    /// # Errors
    ///
    /// Returns error if insufficient signatures
    pub fn enable_throttling(
        config: &mut SecurityConfig,
        signers: &[Pubkey],
        reason: FreezeReason,
    ) -> Result<(), ProgramError> {
        // Validate threshold
        if !config.validate_threshold(signers) {
            return Err(CircuitBreakerError::InsufficientSignatures.into());
        }

        // Set to throttled mode
        config.status = CircuitBreakerStatus::Throttled;

        Ok(())
    }

    /// Disable throttling and return to normal operations
    pub fn disable_throttling(
        config: &mut SecurityConfig,
        signers: &[Pubkey],
    ) -> Result<(), ProgramError> {
        // Validate threshold
        if !config.validate_threshold(signers) {
            return Err(CircuitBreakerError::InsufficientSignatures.into());
        }

        // Set to operational
        if config.status == CircuitBreakerStatus::Throttled {
            config.status = CircuitBreakerStatus::Operational;
        }

        Ok(())
    }

    /// Check if an operation is allowed based on current status
    pub fn check_operation_allowed(
        config: &SecurityConfig,
        operation_type: OperationType,
    ) -> Result<(), ProgramError> {
        match config.status {
            CircuitBreakerStatus::Operational => Ok(()),
            CircuitBreakerStatus::Frozen => Err(ProgramError::Custom(0x200f)), // OperationsFrozen
            CircuitBreakerStatus::Throttled => {
                // Check if operation is allowed in throttled mode
                if operation_type.is_allowed_when_throttled() {
                    Ok(())
                } else {
                    Err(ProgramError::Custom(0x2010)) // OperationThrottled
                }
            }
            CircuitBreakerStatus::Maintenance => {
                if operation_type.is_allowed_when_maintenance() {
                    Ok(())
                } else {
                    Err(ProgramError::Custom(0x2011)) // OperationUnderMaintenance
                }
            }
        }
    }

    /// Add a new guardian
    pub fn add_guardian(
        config: &mut SecurityConfig,
        new_guardian: Pubkey,
        signers: &[Pubkey],
    ) -> Result<(), ProgramError> {
        // Validate threshold
        if !config.validate_threshold(signers) {
            return Err(CircuitBreakerError::InsufficientSignatures.into());
        }

        // Check guardian limit
        if config.guardians.len() >= MAX_GUARDIANS {
            return Err(CircuitBreakerError::TooManyGuardians.into());
        }

        // Add guardian
        if !config.guardians.contains(&new_guardian) {
            config.guardians.push(new_guardian);
        }

        Ok(())
    }

    /// Remove a guardian
    pub fn remove_guardian(
        config: &mut SecurityConfig,
        guardian_to_remove: Pubkey,
        signers: &[Pubkey],
    ) -> Result<(), ProgramError> {
        // Validate threshold
        if !config.validate_threshold(signers) {
            return Err(CircuitBreakerError::InsufficientSignatures.into());
        }

        // Check minimum guardians
        if config.guardians.len() <= MIN_GUARDIANS {
            return Err(CircuitBreakerError::TooFewGuardians.into());
        }

        // Remove guardian
        config.guardians.retain(|g| g != &guardian_to_remove);

        // Adjust threshold if needed
        if config.threshold as usize > config.guardians.len() {
            config.threshold = config.guardians.len() as u8;
        }

        Ok(())
    }

    /// Update the threshold
    pub fn update_threshold(
        config: &mut SecurityConfig,
        new_threshold: u8,
        signers: &[Pubkey],
    ) -> Result<(), ProgramError> {
        // Validate threshold
        if new_threshold as usize > config.guardians.len() {
            return Err(CircuitBreakerError::ThresholdExceedsGuardians.into());
        }

        if new_threshold < 2 {
            return Err(CircuitBreakerError::ThresholdTooLow.into());
        }

        // Validate existing signatures
        if !config.validate_threshold(signers) {
            return Err(CircuitBreakerError::InsufficientSignatures.into());
        }

        config.threshold = new_threshold;

        Ok(())
    }

    /// Update cooldown period
    pub fn update_cooldown(
        config: &mut SecurityConfig,
        new_cooldown: u64,
        signers: &[Pubkey],
    ) -> Result<(), ProgramError> {
        // Validate cooldown
        if new_cooldown > MAX_COOLDOWN_SECS {
            return Err(CircuitBreakerError::CooldownTooLong.into());
        }

        // Validate existing signatures
        if !config.validate_threshold(signers) {
            return Err(CircuitBreakerError::InsufficientSignatures.into());
        }

        config.cooldown_secs = new_cooldown;

        Ok(())
    }
}

/// Types of operations that can be restricted
#[derive(Debug, Clone, Copy)]
pub enum OperationType {
    /// Transfer tokens
    Transfer,
    /// Mint new tokens
    Mint,
    /// Burn tokens
    Burn,
    /// Create new accounts
    CreateAccount,
    /// Update KYC status
    UpdateKyc,
    /// Query compliance status
    QueryCompliance,
    /// Emergency operations
    Emergency,
}

impl OperationType {
    /// Check if allowed during throttled mode
    pub fn is_allowed_when_throttled(&self) -> bool {
        matches!(
            self,
            OperationType::QueryCompliance | OperationType::UpdateKyc
        )
    }

    /// Check if allowed during maintenance
    pub fn is_allowed_when_maintenance(&self) -> bool {
        matches!(self, OperationType::QueryCompliance)
    }
}

/// Program state for circuit breaker
#[derive(Debug, Clone, solana_program::borsh::BorshSerialize, solana_program::borsh::BorshDeserialize)]
pub struct CircuitBreakerState {
    /// Security configuration
    pub config: SecurityConfig,
    /// Freeze history
    pub history: Vec<FreezeEvent>,
    /// Last update timestamp
    pub last_update: i64,
    /// Reserved space
    pub reserved: [u8; 64],
}

impl CircuitBreakerState {
    /// Create a new circuit breaker state
    pub fn new(config: SecurityConfig) -> Self {
        Self {
            config,
            history: Vec::new(),
            last_update: 0,
            reserved: [0u8; 64],
        }
    }

    /// Add a freeze event to history
    pub fn add_freeze_event(&mut self, event: FreezeEvent) -> Result<(), ProgramError> {
        // Check history limit
        if self.history.len() >= self.config.max_history as usize {
            // Remove oldest event
            self.history.remove(0);
        }

        self.history.push(event);
        Ok(())
    }

    /// Get the last freeze event
    pub fn last_freeze(&self) -> Option<&FreezeEvent> {
        self.history.last()
    }

    /// Get freeze count
    pub fn freeze_count(&self) -> usize {
        self.history.iter().filter(|e| !e.resumed).count()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn create_test_config() -> SecurityConfig {
        let guardians = vec![
            Pubkey::new_from_array([1u8; 32]),
            Pubkey::new_from_array([2u8; 32]),
            Pubkey::new_from_array([3u8; 32]),
            Pubkey::new_from_array([4u8; 32]),
        ];
        SecurityConfig::new(guardians, 2).unwrap()
    }

    #[test]
    fn test_security_config_creation() {
        let guardians = vec![
            Pubkey::new_from_array([1u8; 32]),
            Pubkey::new_from_array([2u8; 32]),
            Pubkey::new_from_array([3u8; 32]),
        ];
        let config = SecurityConfig::new(guardians, 2);
        assert!(config.is_ok());
    }

    #[test]
    fn test_too_few_guardians() {
        let guardians = vec![
            Pubkey::new_from_array([1u8; 32]),
            Pubkey::new_from_array([2u8; 32]),
        ];
        let config = SecurityConfig::new(guardians, 2);
        assert!(config.is_err());
    }

    #[test]
    fn test_threshold_validation() {
        let mut config = create_test_config();
        let signers = vec![
            Pubkey::new_from_array([1u8; 32]),
            Pubkey::new_from_array([2u8; 32]),
        ];

        assert!(config.validate_threshold(&signers));

        let invalid_signers = vec![Pubkey::new_from_array([9u8; 32])];
        assert!(!config.validate_threshold(&invalid_signers));
    }

    #[test]
    fn test_freeze_and_resume() {
        let mut config = create_test_config();
        let signers = vec![
            Pubkey::new_from_array([1u8; 32]),
            Pubkey::new_from_array([2u8; 32]),
        ];

        let clock = Clock::default();

        let result = CircuitBreaker::emergency_freeze(
            &mut config,
            FreezeReason::SecurityBreach,
            "Test freeze".to_string(),
            &signers,
            &clock,
        );

        assert!(result.is_ok());
        assert!(config.is_frozen());

        let freeze_event = result.unwrap();
        assert_eq!(freeze_event.reason, FreezeReason::SecurityBreach);
    }
}
