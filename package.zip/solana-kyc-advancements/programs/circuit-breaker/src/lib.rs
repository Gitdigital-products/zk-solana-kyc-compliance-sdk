//! Circuit Breaker Program
//!
//! A standalone program that implements emergency shutdown functionality for the
//! Solana KYC Compliance ecosystem. This program can be invoked by other programs
//! or directly via CPI to halt operations during security incidents.
//!
//! ## Overview
//!
//! The Circuit Breaker provides:
//! - Volume-based threshhold monitoring
//! - Time-window based tracking
//! - Multi-authority control
//! - Emergency pause functionality
//! - Gradual throttling before full stop
//!
//! ## Usage
//!
//! ```rust
//! use circuit_breaker::{initialize, check_volume, pause, resume};
//! ```

use anchor_lang::prelude::*;
use anchor_lang::solana_program::system_program;

/// Program ID
declare_id!("CBreaker1111111111111111111111111111111");

/// Circuit breaker state seeds
pub const STATE_SEED: &[u8] = b"circuit_state";

/// Config seeds
pub const CONFIG_SEED: &[u8] = b"circuit_config";

/// Maximum authorities
pub const MAX_AUTHORITIES: usize = 9;

/// Window duration constants (in seconds)
pub const MIN_WINDOW_DURATION: i64 = 60;        // 1 minute
pub const MAX_WINDOW_DURATION: i64 = 86400;     // 24 hours
pub const DEFAULT_WINDOW_DURATION: i64 = 3600;  // 1 hour

/// Volume threshold constants (in lamports)
pub const MIN_VOLUME_THRESHOLD: u64 = 1_000_000;           // 0.001 SOL
pub const MAX_VOLUME_THRESHOLD: u64 = 1_000_000_000_000;   // 1M SOL
pub const DEFAULT_VOLUME_THRESHOLD: u64 = 100_000_000;      // 0.1 SOL

/// ============== Account Structures ==============

/// Circuit breaker configuration
#[account]
#[derive(InitSpace)]
pub struct CircuitConfig {
    /// Program authority (can update config)
    pub authority: Pubkey,

    /// List of authorized callers
    pub authorities: Vec<Pubkey>,

    /// Required signatures for critical actions
    pub required_signatures: u8,

    /// Window duration in seconds
    pub window_duration: i64,

    /// Volume threshold per window (lamports)
    pub volume_threshold: u64,

    /// Whether circuit breaker is enabled
    pub enabled: bool,

    /// Manual pause switch
    pub paused: bool,

    /// Pause reason
    pub pause_reason: String,

    /// Creation timestamp
    pub created_at: i64,

    /// Reserved space
    pub reserved: [u8; 64],
}

impl CircuitConfig {
    /// Create new configuration
    pub fn new(authority: Pubkey) -> Self {
        Self {
            authority,
            authorities: vec![authority],
            required_signatures: 1,
            window_duration: DEFAULT_WINDOW_DURATION,
            volume_threshold: DEFAULT_VOLUME_THRESHOLD,
            enabled: true,
            paused: false,
            pause_reason: String::new(),
            created_at: Clock::get().unwrap().unix_timestamp,
            reserved: [0u8; 64],
        }
    }

    /// Check if address is authorized
    pub fn is_authorized(&self, address: &Pubkey) -> bool {
        self.authorities.contains(address)
    }

    /// Add authority
    pub fn add_authority(&mut self, new_authority: Pubkey) -> Result<()> {
        require!(!self.authorities.contains(&new_authority), BreakerError::AlreadyAuthorized);
        require!(self.authorities.len() < MAX_AUTHORITIES, BreakerError::TooManyAuthorities);
        self.authorities.push(new_authority);
        Ok(())
    }

    /// Remove authority
    pub fn remove_authority(&mut self, authority: Pubkey) -> Result<()> {
        require!(self.authority != authority, BreakerError::CannotRemoveRoot);
        self.authorities.retain(|a| *a != authority);
        Ok(())
    }
}

/// Circuit breaker state
#[account]
#[derive(InitSpace)]
pub struct CircuitState {
    /// Current window start timestamp
    pub window_start: i64,

    /// Accumulated volume in current window
    pub window_volume: u64,

    /// Number of transactions in window
    pub transaction_count: u64,

    /// Last transaction timestamp
    pub last_transaction: i64,

    /// Number of times circuit triggered
    pub trigger_count: u64,

    /// Last trigger timestamp
    pub last_trigger: i64,

    /// Last trigger reason
    pub last_trigger_reason: String,

    /// Reserved space
    pub reserved: [u8; 64],
}

impl CircuitState {
    /// Create new state
    pub fn new() -> Self {
        let now = Clock::get().unwrap().unix_timestamp;
        Self {
            window_start: now,
            window_volume: 0,
            transaction_count: 0,
            last_transaction: now,
            trigger_count: 0,
            last_trigger: 0,
            last_trigger_reason: String::new(),
            reserved: [0u8; 64],
        }
    }

    /// Reset window
    pub fn reset_window(&mut self) {
        let now = Clock::get().unwrap().unix_timestamp;
        self.window_start = now;
        self.window_volume = 0;
        self.transaction_count = 0;
    }

    /// Record transaction
    pub fn record_transaction(&mut self, amount: u64) -> Result<bool> {
        let clock = Clock::get().unwrap();
        let now = clock.unix_timestamp;

        // Check if we need a new window
        if now - self.window_start >= 3600 { // 1 hour window
            self.reset_window();
        }

        // Record transaction
        self.window_volume = self.window_volume.saturating_add(amount);
        self.transaction_count = self.transaction_count.saturating_add(1);
        self.last_transaction = now;

        // Check if threshold exceeded
        if self.window_volume > 100_000_000 { // Default threshold
            self.trigger_count = self.trigger_count.saturating_add(1);
            self.last_trigger = now;
            return Ok(true);
        }

        Ok(false)
    }
}

impl Default for CircuitState {
    fn default() -> Self {
        Self::new()
    }
}

/// ============== Instructions ==============

/// Initialize circuit breaker
#[derive(Accounts)]
pub struct Initialize<'info> {
    #[account(
        init,
        payer = payer,
        space = 8 + CircuitConfig::INIT_SPACE,
        seeds = [CONFIG_SEED],
        bump
    )]
    pub config: Account<'info, CircuitConfig>,

    #[account(
        init,
        payer = payer,
        space = 8 + CircuitState::INIT_SPACE,
        seeds = [STATE_SEED],
        bump
    )]
    pub state: Account<'info, CircuitState>,

    #[account(mut, signer)]
    pub payer: Signer<'info>,

    #[account(address = system_program::ID)]
    pub system_program: Program<'info, System>,
}

/// Initialize handler
pub fn initialize(ctx: Context<Initialize>) -> Result<()> {
    let config = &mut ctx.accounts.config;
    let state = &mut ctx.accounts.state;

    let authority = ctx.accounts.payer.key();
    *config = CircuitConfig::new(authority);
    *state = CircuitState::new();

    msg!("Circuit breaker initialized by {}", authority);
    Ok(())
}

/// Update configuration
#[derive(Accounts)]
pub struct UpdateConfig<'info> {
    #[account(
        mut,
        seeds = [CONFIG_SEED],
        bump,
        has_one = authority
    )]
    pub config: Account<'info, CircuitConfig>,

    #[account(signer)]
    pub authority: Signer<'info>,
}

/// Update config handler
pub fn update_config(
    ctx: Context<UpdateConfig>,
    window_duration: Option<i64>,
    volume_threshold: Option<u64>,
    required_signatures: Option<u8>,
) -> Result<()> {
    let config = &mut ctx.accounts.config;

    if let Some(duration) = window_duration {
        require!(duration >= MIN_WINDOW_DURATION, BreakerError::InvalidWindowDuration);
        require!(duration <= MAX_WINDOW_DURATION, BreakerError::InvalidWindowDuration);
        config.window_duration = duration;
    }

    if let Some(threshold) = volume_threshold {
        require!(threshold >= MIN_VOLUME_THRESHOLD, BreakerError::InvalidThreshold);
        require!(threshold <= MAX_VOLUME_THRESHOLD, BreakerError::InvalidThreshold);
        config.volume_threshold = threshold;
    }

    if let Some(sigs) = required_signatures {
        require!(sigs > 0, BreakerError::InvalidSignatures);
        require!(sigs <= config.authorities.len() as u8, BreakerError::InvalidSignatures);
        config.required_signatures = sigs;
    }

    msg!("Configuration updated");
    Ok(())
}

/// Check volume and trigger if needed
#[derive(Accounts)]
pub struct CheckVolume<'info> {
    #[account(
        seeds = [CONFIG_SEED],
        bump,
        constraint = config.enabled @ BreakerError::BreakerDisabled
    )]
    pub config: Account<'info, CircuitConfig>,

    #[account(
        mut,
        seeds = [STATE_SEED],
        bump
    )]
    pub state: Account<'info, CircuitState>,
}

/// Check volume handler
pub fn check_volume(ctx: Context<CheckVolume>, amount: u64) -> Result<bool> {
    let config = &ctx.accounts.config;
    let state = &mut ctx.accounts.state;

    // Check if manually paused
    if config.paused {
        return Err(BreakerError::CircuitPaused.into());
    }

    // Record transaction and check threshold
    let triggered = state.record_transaction(amount)?;

    if triggered {
        state.last_trigger_reason = format!(
            "Volume threshold exceeded: {} lamports",
            state.window_volume
        );
        msg!("⚠️ Circuit breaker triggered: {}", state.last_trigger_reason);
    }

    Ok(triggered)
}

/// Emergency pause
#[derive(Accounts)]
pub struct EmergencyPause<'info> {
    #[account(
        mut,
        seeds = [CONFIG_SEED],
        bump,
        constraint = !config.paused @ BreakerError::AlreadyPaused
    )]
    pub config: Account<'info, CircuitConfig>,

    #[account(signer)]
    pub authority: Signer<'info>,
}

/// Emergency pause handler
pub fn emergency_pause(ctx: Context<EmergencyPause>, reason: String) -> Result<()> {
    let config = &mut ctx.accounts.config;

    require!(config.is_authority(&ctx.accounts.authority.key()), BreakerError::Unauthorized);

    config.paused = true;
    config.pause_reason = reason.clone();

    msg!("🚨 Circuit breaker paused: {}", reason);
    Ok(())
}

/// Resume operations
#[derive(Accounts)]
pub struct Resume<'info> {
    #[account(
        mut,
        seeds = [CONFIG_SEED],
        bump,
        constraint = config.paused @ BreakerError::NotPaused
    )]
    pub config: Account<'info, CircuitConfig>,

    #[account(signer)]
    pub authority: Signer<'info>,
}

/// Resume handler
pub fn resume(ctx: Context<Resume>) -> Result<()> {
    let config = &mut ctx.accounts.config;

    require!(config.is_authority(&ctx.accounts.authority.key()), BreakerError::Unauthorized);

    config.paused = false;
    config.pause_reason = String::new();

    msg!("✅ Circuit breaker resumed");
    Ok(())
}

/// Add authority
#[derive(Accounts)]
pub struct AddAuthority<'info> {
    #[account(
        mut,
        seeds = [CONFIG_SEED],
        bump,
        has_one = authority
    )]
    pub config: Account<'info, CircuitConfig>,

    #[account(signer)]
    pub authority: Signer<'info>,
}

/// Add authority handler
pub fn add_authority(ctx: Context<AddAuthority>, new_authority: Pubkey) -> Result<()> {
    let config = &mut ctx.accounts.config;
    config.add_authority(new_authority)?;
    msg!("Authority added: {}", new_authority);
    Ok(())
}

/// Remove authority
#[derive(Accounts)]
pub struct RemoveAuthority<'info> {
    #[account(
        mut,
        seeds = [CONFIG_SEED],
        bump,
        has_one = authority
    )]
    pub config: Account<'info, CircuitConfig>,

    #[account(signer)]
    pub authority: Signer<'info>,
}

/// Remove authority handler
pub fn remove_authority(ctx: Context<RemoveAuthority>, authority_to_remove: Pubkey) -> Result<()> {
    let config = &mut ctx.accounts.config;
    config.remove_authority(authority_to_remove)?;
    msg!("Authority removed: {}", authority_to_remove);
    Ok(())
}

/// Reset state
#[derive(Accounts)]
pub struct ResetState<'info> {
    #[account(
        mut,
        seeds = [CONFIG_SEED],
        bump
    )]
    pub config: Account<'info, CircuitConfig>,

    #[account(
        mut,
        seeds = [STATE_SEED],
        bump
    )]
    pub state: Account<'info, CircuitState>,

    #[account(signer)]
    pub authority: Signer<'info>,
}

/// Reset state handler
pub fn reset_state(ctx: Context<ResetState>) -> Result<()> {
    require!(ctx.accounts.config.is_authority(&ctx.accounts.authority.key()), BreakerError::Unauthorized);

    let state = &mut ctx.accounts.state;
    state.reset_window();

    msg!("Circuit breaker state reset");
    Ok(())
}

/// ============== Error Codes ==============

#[error_code]
pub enum BreakerError {
    #[msg("Circuit breaker is disabled")]
    BreakerDisabled,

    #[msg("Circuit is currently paused")]
    CircuitPaused,

    #[msg("Circuit is not paused")]
    NotPaused,

    #[msg("Already paused")]
    AlreadyPaused,

    #[msg("Invalid window duration")]
    InvalidWindowDuration,

    #[msg("Invalid volume threshold")]
    InvalidThreshold,

    #[msg("Invalid signature count")]
    InvalidSignatures,

    #[msg("Unauthorized caller")]
    Unauthorized,

    #[msg("Authority already exists")]
    AlreadyAuthorized,

    #[msg("Too many authorities")]
    TooManyAuthorities,

    #[msg("Cannot remove root authority")]
    CannotRemoveRoot,

    #[msg("Threshold not exceeded")]
    ThresholdNotExceeded,
}

/// ============== CPI Helper ==============

/// CPI helper for other programs to check circuit breaker
pub fn check_breaker<'a, 'b, 'c, 'info>(
    program_id: &'a Pubkey,
    accounts: &'b [AccountInfo<'info>],
    amount: u64,
) -> Result<bool> {
    let config_info = &accounts[0];
    let state_info = &accounts[1];

    // Deserialize accounts
    let config = CircuitConfig::try_from_slice(&config_info.data.borrow())?;
    let mut state = CircuitState::try_from_slice(&state_info.data.borrow())?;

    // Check if paused
    if config.paused {
        return Err(BreakerError::CircuitPaused.into());
    }

    // Record and check
    let triggered = state.record_transaction(amount)?;

    // Serialize state back
    state.serialize(&mut &mut state_info.data.borrow_mut()[8..])?;

    Ok(triggered)
}

/// ============== Events ==============

#[event]
pub struct CircuitBreakerTriggered {
    pub window_volume: u64,
    pub threshold: u64,
    pub transaction_count: u64,
    pub reason: String,
    pub timestamp: i64,
}

#[event]
pub struct CircuitBreakerPaused {
    pub authority: Pubkey,
    pub reason: String,
    pub timestamp: i64,
}

#[event]
pub struct CircuitBreakerResumed {
    pub authority: Pubkey,
    pub timestamp: i64,
}

#[event]
pub struct ConfigurationUpdated {
    pub authority: Pubkey,
    pub window_duration: Option<i64>,
    pub volume_threshold: Option<u64>,
    pub timestamp: i64,
}
