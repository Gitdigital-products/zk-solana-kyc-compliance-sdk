#!/usr/bin/env node

/**
 * Checklist Tracker
 *
 * A utility script to track the implementation status of compliance features
 * across the repository. This script helps teams monitor progress on feature
 * implementation and identify gaps.
 *
 * ## Features
 *
 * - Track feature implementation status
 * - Generate progress reports
 * - Check for missing documentation
 * - Verify test coverage
 * - Monitor dependency updates
 *
 * ## Usage
 *
 * Basic usage:
 *   node checklist-tracker.js
 *
 * With options:
 *   node checklist-tracker.js --check-docs --check-tests --output report.md
 *
 * Check specific category:
 *   node checklist-tracker.js --category security
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

// Configuration
const CONFIG = {
  categories: {
    security: {
      name: 'Security & Privacy',
      features: [
        'verify_zk_proof.rs',
        'circuit_breaker_program.rs',
        'admin_only.rs',
        'crypto.rs'
      ]
    },
    risk: {
      name: 'Risk & Compliance',
      features: [
        'auto_sanctioning_ai.ts',
        'scoring.rs',
        'aggregator.rs',
        'attestation_state_manager.ts'
      ]
    },
    infrastructure: {
      name: 'Institutional Infrastructure',
      features: [
        'rwa_registry.rs',
        'wasm/index.ts',
        'instructions.rs',
        'batch_operations.ts'
      ]
    },
    devops: {
      name: 'Developer & DevOps',
      features: [
        'security-audit.yml',
        'codeql.yml',
        'checklist-tracker.js',
        'ISSUE_TEMPLATE'
      ]
    }
  },
  checkCategories: ['docs', 'tests', 'types'],
  rootDir: process.cwd()
};

// Feature status tracking
const featureStatus = new Map();

// Initialize status
function initializeStatus() {
  for (const [categoryKey, category] of Object.entries(CONFIG.categories)) {
    for (const feature of category.features) {
      const key = `${categoryKey}/${feature}`;
      featureStatus.set(key, {
        category: categoryKey,
        feature,
        exists: false,
        hasTests: false,
        hasDocs: false,
        hasTypes: false,
        lastUpdated: null,
        issues: []
      });
    }
  }
}

// Check if file exists
function checkFileExists(relativePath) {
  const fullPath = path.join(CONFIG.rootDir, relativePath);
  return fs.existsSync(fullPath);
}

// Check for test files
function checkForTests(featurePath) {
  const extensions = ['.test.ts', '.test.rs', '.spec.ts', '_test.rs'];
  const basePath = featurePath.replace(/\.[^/.]+$/, '');

  for (const ext of extensions) {
    const testPath = path.join(CONFIG.rootDir, `${basePath}${ext}`);
    const testPathAlt = path.join(CONFIG.rootDir, 'tests', `${basePath}${ext}`);

    if (fs.existsSync(testPath) || fs.existsSync(testPathAlt)) {
      return true;
    }
  }
  return false;
}

// Check for documentation
function checkForDocs(featurePath) {
  const docExtensions = ['.md', '.rst', '.txt'];
  const basePath = featurePath.replace(/\.[^/.]+$/, '');

  // Check for README
  const readmePath = path.join(CONFIG.rootDir, basePath, 'README.md');
  if (fs.existsSync(readmePath)) {
    return true;
  }

  // Check for docs directory
  const docsPath = path.join(CONFIG.rootDir, 'docs', `${basePath}.md`);
  if (fs.existsSync(docsPath)) {
    return true;
  }

  return false;
}

// Check for TypeScript types
function checkForTypes(featurePath) {
  // For TypeScript files, check for .d.ts files
  if (featurePath.endsWith('.ts')) {
    const dtsPath = featurePath.replace('.ts', '.d.ts');
    return checkFileExists(dtsPath);
  }
  // For Rust, check for documentation comments
  if (featurePath.endsWith('.rs')) {
    return true; // Rust has inline docs
  }
  return true;
}

// Scan repository
function scanRepository(options) {
  console.log('Scanning repository...\n');

  for (const [key, status] of featureStatus) {
    const [category, feature] = key.split('/');

    // Check if file exists
    const exists = checkFileExists(feature);
    status.exists = exists;

    if (exists) {
      // Check for tests
      if (options.checkTests) {
        status.hasTests = checkForTests(feature);
      }

      // Check for docs
      if (options.checkDocs) {
        status.hasDocs = checkForDocs(feature);
      }

      // Check for types
      if (options.checkTypes) {
        status.hasTypes = checkForTypes(feature);
      }

      // Try to get last updated time
      try {
        const fullPath = path.join(CONFIG.rootDir, feature);
        const stats = fs.statSync(fullPath);
        status.lastUpdated = stats.mtime;
      } catch (e) {
        // Ignore errors
      }
    }

    // Collect issues
    if (!status.exists) {
      status.issues.push('Feature file not found');
    }
    if (options.checkTests && !status.hasTests) {
      status.issues.push('Missing tests');
    }
    if (options.checkDocs && !status.hasDocs) {
      status.issues.push('Missing documentation');
    }
  }
}

// Generate report
function generateReport(options) {
  let report = '';

  report += '# Compliance Feature Implementation Status\n\n';
  report += `Generated: ${new Date().toISOString()}\n\n`;

  // Summary
  let total = 0;
  let implemented = 0;
  let withTests = 0;
  let withDocs = 0;

  for (const [key, status] of featureStatus) {
    total++;
    if (status.exists) implemented++;
    if (status.hasTests) withTests++;
    if (status.hasDocs) withDocs++;
  }

  report += '## Summary\n\n';
  report += `- Total Features: ${total}\n`;
  report += `- Implemented: ${implemented} (${Math.round(implemented/total*100)}%)\n`;
  report += `- With Tests: ${withTests} (${Math.round(withTests/total*100)}%)\n`;
  report += `- With Docs: ${withDocs} (${Math.round(withDocs/total*100)}%)\n\n`;

  // Per-category breakdown
  for (const [categoryKey, category] of Object.entries(CONFIG.categories)) {
    report += `## ${category.name}\n\n`;
    report += '| Feature | Status | Tests | Docs | Issues |\n';
    report += '|---------|--------|-------|------|--------|\n';

    for (const feature of category.features) {
      const key = `${categoryKey}/${feature}`;
      const status = featureStatus.get(key);

      const statusIcon = status.exists ? ':white_check_mark:' : ':x:';
      const testIcon = status.hasTests ? ':white_check_mark:' : ':x:';
      const docIcon = status.hasDocs ? ':white_check_mark:' : ':x:';
      const issues = status.issues.length > 0 ? status.issues.join(', ') : '-';

      report += `| ${feature} | ${statusIcon} | ${testIcon} | ${docIcon} | ${issues} |\n`;
    }

    report += '\n';
  }

  // Recommendations
  report += '## Recommendations\n\n';

  const missingTests = [];
  const missingDocs = [];

  for (const [key, status] of featureStatus) {
    if (status.exists) {
      if (!status.hasTests && options.checkTests) {
        missingTests.push(key);
      }
      if (!status.hasDocs && options.checkDocs) {
        missingDocs.push(key);
      }
    }
  }

  if (missingTests.length > 0) {
    report += '### Add Tests\n\n';
    for (const item of missingTests) {
      report += `- ${item}\n`;
    }
    report += '\n';
  }

  if (missingDocs.length > 0) {
    report += '### Add Documentation\n\n';
    for (const item of missingDocs) {
      report += `- ${item}\n`;
    }
    report += '\n';
  }

  if (missingTests.length === 0 && missingDocs.length === 0) {
    report += 'All features have tests and documentation!\n\n';
  }

  return report;
}

// Console output
function printToConsole(report) {
  console.log('\n' + '='.repeat(60));
  console.log('COMPLIANCE FEATURE IMPLEMENTATION STATUS');
  console.log('='.repeat(60) + '\n');

  // Parse summary from report
  const summaryMatch = report.match(/## Summary\n\n([^#]+)/);
  if (summaryMatch) {
    console.log(summaryMatch[1].trim());
    console.log('');
  }

  // Show progress bar
  const totalMatch = report.match(/- Total Features: (\d+)/);
  const implementedMatch = report.match(/- Implemented: (\d+)/);

  if (totalMatch && implementedMatch) {
    const total = parseInt(totalMatch[1]);
    const implemented = parseInt(implementedMatch[1]);
    const percentage = Math.round((implemented / total) * 100);

    const barLength = 30;
    const filled = Math.round((implemented / total) * barLength);
    const bar = '='.repeat(filled) + '-'.repeat(barLength - filled);

    console.log(`Progress: [${bar}] ${percentage}%`);
    console.log('');
  }

  // Show any issues
  const issuesMatch = report.match(/## Recommendations\n\n([^#]+)/);
  if (issuesMatch && options.verbose) {
    console.log('Issues Found:');
    console.log(issuesMatch[1].trim());
  }
}

// Parse command line arguments
const args = process.argv.slice(2);
const options = {
  checkTests: args.includes('--check-tests') || args.includes('-t'),
  checkDocs: args.includes('--check-docs') || args.includes('-d'),
  checkTypes: args.includes('--check-types') || args.includes('-y'),
  output: null,
  verbose: args.includes('--verbose') || args.includes('-v'),
  category: null,
  help: args.includes('--help') || args.includes('-h')
};

// Parse output option
const outputIndex = args.indexOf('--output');
if (outputIndex !== -1 && args[outputIndex + 1]) {
  options.output = args[outputIndex + 1];
}

// Parse category option
const categoryIndex = args.indexOf('--category');
if (categoryIndex !== -1 && args[categoryIndex + 1]) {
  options.category = args[categoryIndex + 1];
}

// Default options
if (!options.checkTests && !options.checkDocs && !options.checkTypes) {
  options.checkTests = true;
  options.checkDocs = true;
}

// Show help
if (options.help) {
  console.log(`
Checklist Tracker - Compliance Feature Implementation Status

Usage:
  node checklist-tracker.js [options]

Options:
  --check-tests, -t      Check for test files
  --check-docs, -d      Check for documentation
  --check-types, -y     Check for type definitions
  --category, -c        Check specific category (security, risk, infrastructure, devops)
  --output, -o          Output to file
  --verbose, -v         Show detailed issues
  --help, -h            Show this help message

Examples:
  node checklist-tracker.js
  node checklist-tracker.js --check-tests --check-docs
  node checklist-tracker.js --category security
  node checklist-tracker.js --output status.md
  `);
  process.exit(0);
}

// Main execution
console.log('Checklist Tracker');
console.log('================\n');

// Filter by category if specified
let categoriesToCheck = Object.entries(CONFIG.categories);
if (options.category) {
  categoriesToCheck = categoriesToCheck.filter(([key]) => key === options.category);

  if (categoriesToCheck.length === 0) {
    console.error(`Unknown category: ${options.category}`);
    console.log(`Available categories: ${Object.keys(CONFIG.categories).join(', ')}`);
    process.exit(1);
  }
}

// Filter categories
const originalCategories = CONFIG.categories;
CONFIG.categories = Object.fromEntries(categoriesToCheck);

// Initialize and scan
initializeStatus();
scanRepository(options);

// Generate report
const report = generateReport(options);

// Output
if (options.output) {
  const outputPath = path.join(CONFIG.rootDir, options.output);
  fs.writeFileSync(outputPath, report);
  console.log(`Report saved to: ${options.output}`);
} else {
  printToConsole(report);
}

// Exit with error if there are missing features
let missingCount = 0;
for (const [key, status] of featureStatus) {
  if (!status.exists) missingCount++;
}

if (missingCount > 0) {
  console.log(`\n:warning: ${missingCount} features not found`);
  // Don't exit with error - this is expected during development
}

// Export for programmatic use
module.exports = {
  CONFIG,
  featureStatus,
  scanRepository,
  generateReport,
  options
};
