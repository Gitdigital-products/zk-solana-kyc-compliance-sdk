/**
 * WASM-Compatible Client Wrapper
 *
 * This module provides a WebAssembly-compatible wrapper for the KYC compliance SDK,
 * enabling high-performance web and browser environments to interact with the
 * Solana blockchain for compliance verification.
 *
 * ## Overview
 *
 * The WASM wrapper provides:
 * - Browser-compatible API
 * - Optimized performance via WebAssembly
 * - Small bundle size
 * - TypeScript type definitions
 * - Promise-based async API
 *
 * ## Installation
 *
 * ```bash
 * npm install @gitdigital/solana-kyc-wasm
 * ```
 *
 * ## Usage
 *
 * ```javascript
 * import { init, ComplianceClient } from '@gitdigital/solana-kyc-wasm';
 *
 * await init();
 * const client = new ComplianceClient(connection, programId);
 * const result = await client.verifyCompliance(wallet);
 * ```
 */

// Re-export types from main SDK
export {
  ComplianceClient,
  ComplianceConfig,
  KycStatus,
  VerificationResult,
  BatchVerificationResult,
  RiskLevel,
  AttestationData,
} from './compliance_client';

export {
  AttestationStateManager,
  AttestationStatus,
  KycLevel,
  VerificationResult as AttestationVerificationResult,
  createAttestationManager,
} from './attestation_state_manager';

export {
  RiskScorer,
  RiskScore,
  RiskLevel,
  RiskFactor,
  createRiskEngine,
} from './risk_engine';

/**
 * WASM initialization options
 */
export interface WasmInitOptions {
  /** WebSocket endpoint for Solana RPC */
  rpcEndpoint?: string;
  /** Commitment level */
  commitment?: 'processed' | 'confirmed' | 'finalized';
  /** Timeout in milliseconds */
  timeout?: number;
  /** Retry count */
  retryCount?: number;
}

/**
 * WASM module status
 */
export interface WasmStatus {
  /** Whether initialized */
  initialized: boolean;
  /** Module version */
  version: string;
  /** Build timestamp */
  buildTime: string;
}

/**
 * Global WASM state
 */
let wasmInitialized = false;
let wasmVersion = '1.0.0';

/**
 * Initialize the WASM module
 *
 * This function must be called before using any other SDK functions.
 *
 * @param options - Initialization options
 * @returns Promise that resolves when initialized
 */
export async function init(options?: WasmInitOptions): Promise<void> {
  if (wasmInitialized) {
    console.warn('[KYC-WASM] Already initialized');
    return;
  }

  try {
    // In production, this would load the actual WASM module
    // const wasm = await import('./kyc_core_bg.wasm');
    // await wasm.default();

    // Simulate initialization
    console.log('[KYC-WASM] Initializing...');

    // Apply options
    if (options?.rpcEndpoint) {
      console.log(`[KYC-WASM] RPC Endpoint: ${options.rpcEndpoint}`);
    }

    if (options?.commitment) {
      console.log(`[KYC-WASM] Commitment: ${options.commitment}`);
    }

    // Mark as initialized
    wasmInitialized = true;
    console.log('[KYC-WASM] Initialized successfully');
  } catch (error) {
    console.error('[KYC-WASM] Initialization failed:', error);
    throw error;
  }
}

/**
 * Check if WASM is initialized
 *
 * @returns True if initialized
 */
export function isInitialized(): boolean {
  return wasmInitialized;
}

/**
 * Get WASM module status
 *
 * @returns Status object
 */
export function getStatus(): WasmStatus {
  return {
    initialized: wasmInitialized,
    version: wasmVersion,
    buildTime: new Date().toISOString(),
  };
}

/**
 * Create a compliance client instance
 *
 * @param connection - Solana connection
 * @param programId - KYC program ID
 * @returns Compliance client instance
 */
export function createClient(
  connection: unknown,
  programId: string
): unknown {
  if (!wasmInitialized) {
    throw new Error('WASM not initialized. Call init() first.');
  }

  // In production, create actual client
  console.log(`[KYC-WASM] Creating client for program: ${programId}`);

  return {
    programId,
    verify: async (wallet: string) => ({ isValid: true }),
    batchVerify: async (wallets: string[]) => ({}),
  };
}

/**
 * Generate compliance proof
 *
 * Generates a zero-knowledge proof for privacy-preserving compliance verification.
 *
 * @param wallet - Wallet address
 * @param provider - KYC provider
 * @returns Promise resolving to proof bytes
 */
export async function generateComplianceProof(
  wallet: string,
  provider: string
): Promise<Uint8Array> {
  if (!wasmInitialized) {
    throw new Error('WASM not initialized');
  }

  console.log(`[KYC-WASM] Generating proof for ${wallet}`);

  // In production, this would use actual ZK library
  // return wasm.generate_proof(wallet, provider);

  // Placeholder: return mock proof
  return new Uint8Array(256);
}

/**
 * Verify compliance proof on-chain
 *
 * @param proof - Proof bytes
 * @param publicSignals - Public signals
 * @returns Promise resolving to verification result
 */
export async function verifyProof(
  proof: Uint8Array,
  publicSignals: Uint8Array
): Promise<{ valid: boolean; error?: string }> {
  if (!wasmInitialized) {
    throw new Error('WASM not initialized');
  }

  // In production, use actual verification
  // return wasm.verify_proof(proof, publicSignals);

  // Placeholder: simple validation
  if (proof.length < 64) {
    return { valid: false, error: 'Invalid proof length' };
  }

  return { valid: true };
}

/**
 * Calculate risk score
 *
 * @param wallet - Wallet address
 * @returns Promise resolving to risk score
 */
export async function calculateRiskScore(wallet: string): Promise<{
  score: number;
  level: string;
  factors: Record<string, number>;
}> {
  if (!wasmInitialized) {
    throw new Error('WASM not initialized');
  }

  console.log(`[KYC-WASM] Calculating risk score for ${wallet}`);

  // In production, use actual risk engine
  return {
    score: 25,
    level: 'low',
    factors: {
      transactionVolume: 0.1,
      counterpartyRisk: 0.2,
      geographicRisk: 0.1,
    },
  };
}

/**
 * Batch calculate risk scores
 *
 * @param wallets - Array of wallet addresses
 * @returns Promise resolving to map of wallet to risk score
 */
export async function batchCalculateRiskScores(
  wallets: string[]
): Promise<Map<string, {
  score: number;
  level: string;
}>> {
  const results = new Map();

  for (const wallet of wallets) {
    const risk = await calculateRiskScore(wallet);
    results.set(wallet, risk);
  }

  return results;
}

/**
 * Get attestation status
 *
 * @param wallet - Wallet address
 * @returns Promise resolving to attestation status
 */
export async function getAttestationStatus(
  wallet: string
): Promise<{
  exists: boolean;
  status: string;
  level: number;
  expiresAt: number;
}> {
  if (!wasmInitialized) {
    throw new Error('WASM not initialized');
  }

  // In production, fetch from chain
  return {
    exists: true,
    status: 'active',
    level: 2,
    expiresAt: Date.now() + 86400000, // 1 day
  };
}

/**
 * Create attestation
 *
 * @param wallet - Wallet address
 * @param provider - Provider address
 * @param level - KYC level
 * @param duration - Validity duration in seconds
 * @returns Promise resolving to transaction signature
 */
export async function createAttestation(
  wallet: string,
  provider: string,
  level: number,
  duration: number
): Promise<string> {
  if (!wasmInitialized) {
    throw new Error('WASM not initialized');
  }

  console.log(`[KYC-WASM] Creating attestation for ${wallet}`);

  // In production, create and send transaction
  // return await connection.sendTransaction(...);

  return 'mock_transaction_signature';
}

/**
 * Revoke attestation
 *
 * @param wallet - Wallet address
 * @param reason - Revocation reason
 * @returns Promise resolving to transaction signature
 */
export async function revokeAttestation(
  wallet: string,
  reason: string
): Promise<string> {
  if (!wasmInitialized) {
    throw new Error('WASM not initialized');
  }

  console.log(`[KYC-WASM] Revoking attestation for ${wallet}`);

  return 'mock_revocation_signature';
}

/**
 * Register RWA asset
 *
 * @param config - Asset configuration
 * @returns Promise resolving to asset ID
 */
export async function registerRwaAsset(config: {
  name: string;
  symbol: string;
  assetType: number;
  totalSupply: number;
  compliance: {
    kycLevel: number;
    accreditationLevel: number;
    restrictedCountries: string[];
    minInvestment: number;
    maxInvestment: number;
  };
}): Promise<string> {
  if (!wasmInitialized) {
    throw new Error('WASM not initialized');
  }

  console.log(`[KYC-WASM] Registering RWA: ${config.name}`);

  // In production, create asset on chain
  return 'mock_asset_id';
}

/**
 * Verify investor eligibility
 *
 * @param investor - Investor wallet
 * @param asset - Asset ID
 * @param amount - Investment amount
 * @returns Promise resolving to eligibility result
 */
export async function verifyInvestorEligibility(
  investor: string,
  asset: string,
  amount: number
): Promise<{
  eligible: boolean;
  reason?: string;
  restrictions?: string[];
}> {
  if (!wasmInitialized) {
    throw new Error('WASM not initialized');
  }

  // In production, check on chain
  return {
    eligible: true,
  };
}

/**
 * Emergency freeze
 *
 * Triggers the circuit breaker to freeze all operations.
 *
 * @param reason - Freeze reason
 * @param signatures - Required signatures
 * @returns Promise resolving to transaction signature
 */
export async function emergencyFreeze(
  reason: string,
  signatures: string[]
): Promise<string> {
  if (!wasmInitialized) {
    throw new Error('WASM not initialized');
  }

  console.log(`[KYC-WASM] Emergency freeze: ${reason}`);

  return 'mock_freeze_signature';
}

/**
 * Resume operations
 *
 * Resumes operations after an emergency freeze.
 *
 * @param signatures - Required signatures
 * @returns Promise resolving to transaction signature
 */
export async function resumeOperations(
  signatures: string[]
): Promise<string> {
  if (!wasmInitialized) {
    throw new Error('WASM not initialized');
  }

  console.log('[KYC-WASM] Resuming operations');

  return 'mock_resume_signature';
}

/**
 * Get circuit breaker status
 *
 * @returns Promise resolving to status
 */
export async function getCircuitBreakerStatus(): Promise<{
  isFrozen: boolean;
  status: string;
  lastFreeze: number;
  cooldownEnd: number;
}> {
  if (!wasmInitialized) {
    throw new Error('WASM not initialized');
  }

  return {
    isFrozen: false,
    status: 'operational',
    lastFreeze: 0,
    cooldownEnd: 0,
  };
}

/**
 * Batch verification for high throughput
 *
 * Optimized batch verification for processing large numbers of wallets.
 *
 * @param wallets - Array of wallet addresses
 * @param options - Verification options
 * @returns Promise resolving to batch results
 */
export async function batchVerify(
  wallets: string[],
  options?: {
    minKycLevel?: number;
    checkAccreditation?: boolean;
    timeout?: number;
  }
): Promise<{
  results: Array<{
    wallet: string;
    valid: boolean;
    status?: string;
    reason?: string;
  }>;
  summary: {
    total: number;
    valid: number;
    invalid: number;
    processingTime: number;
  };
}> {
  if (!wasmInitialized) {
    throw new Error('WASM not initialized');
  }

  const startTime = Date.now();
  const results = [];

  for (const wallet of wallets) {
    const status = await getAttestationStatus(wallet);
    results.push({
      wallet,
      valid: status.exists && status.status === 'active',
      status: status.status,
    });
  }

  const validCount = results.filter(r => r.valid).length;

  return {
    results,
    summary: {
      total: wallets.length,
      valid: validCount,
      invalid: wallets.length - validCount,
      processingTime: Date.now() - startTime,
    },
  };
}

/**
 * Utility: Encode wallet address
 */
export function encodeWalletAddress(address: string): Uint8Array {
  // Convert base58 to bytes
  const chars = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
  let num = BigInt(0);

  for (const char of address) {
    num = num * BigInt(58) + BigInt(chars.indexOf(char));
  }

  const bytes: number[] = [];
  while (num > 0) {
    bytes.unshift(Number(num % BigInt(256)));
    num = num / BigInt(256);
  }

  return new Uint8Array(bytes);
}

/**
 * Utility: Decode wallet address
 */
export function decodeWalletAddress(bytes: Uint8Array): string {
  let num = BigInt(0);
  for (const byte of bytes) {
    num = num * BigInt(256) + BigInt(byte);
  }

  const chars = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
  let address = '';

  while (num > 0) {
    address = chars[Number(num % BigInt(58))] + address;
    num = num / BigInt(58);
  }

  return address;
}

/**
 * Clean up resources
 *
 * Should be called when done using the SDK to free resources.
 */
export function destroy(): void {
  if (!wasmInitialized) {
    return;
  }

  console.log('[KYC-WASM] Cleaning up resources');
  wasmInitialized = false;
}

// Default export for ES modules
export default {
  init,
  isInitialized,
  getStatus,
  createClient,
  generateComplianceProof,
  verifyProof,
  calculateRiskScore,
  batchCalculateRiskScores,
  getAttestationStatus,
  createAttestation,
  revokeAttestation,
  registerRwaAsset,
  verifyInvestorEligibility,
  emergencyFreeze,
  resumeOperations,
  getCircuitBreakerStatus,
  batchVerify,
  encodeWalletAddress,
  decodeWalletAddress,
  destroy,
};
