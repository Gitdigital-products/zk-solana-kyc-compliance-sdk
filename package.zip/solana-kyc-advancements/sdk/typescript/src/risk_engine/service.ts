/**
 * Risk Engine Service
 *
 * Background monitoring service that continuously scans for compliance updates
 * and risk alerts. This service aggregates data from multiple sources and
 * calculates real-time risk scores for wallets in the registry.
 *
 * ## Overview
 *
 * The Risk Engine Service:
 * - Monitors on-chain activity for registered wallets
 * - Queries external risk intelligence providers
 * - Calculates and updates risk scores
 * - Triggers alerts for high-risk activities
 * - Provides data for the admin dashboard
 *
 * ## Usage
 *
 * ```typescript
 * import { RiskEngineService } from './service';
 *
 * const service = new RiskEngineService(connection, config);
 * await service.start();
 * ```
 */

import { Connection, PublicKey } from '@solana/web3.js';
import { RiskScore, RiskLevel, RiskFactor } from './scoring';

/**
 * Risk engine configuration
 */
export interface RiskEngineConfig {
  /** RPC connection */
  connection: Connection;
  /** Program ID for KYC compliance */
  kycProgramId: PublicKey;
  /** Risk program ID */
  riskProgramId: PublicKey;
  /** Scan interval in milliseconds */
  scanIntervalMs: number;
  /** Batch size for processing */
  batchSize: number;
  /** Minimum score change to trigger update */
  scoreChangeThreshold: number;
  /** Alert threshold */
  alertThreshold: number;
  /** Providers to use */
  providers: RiskProviderConfig[];
}

/**
 * Risk provider configuration
 */
export interface RiskProviderConfig {
  /** Provider name */
  name: string;
  /** API endpoint */
  endpoint: string;
  /** API key (optional) */
  apiKey?: string;
  /** Weight in aggregation (0-100) */
  weight: number;
  /** Whether enabled */
  enabled: boolean;
}

/**
 * Scan result
 */
export interface ScanResult {
  /** Wallet address */
  wallet: PublicKey;
  /** Previous risk score */
  previousScore: number;
  /** New risk score */
  newScore: number;
  /** Score change */
  scoreChange: number;
  /** Risk level */
  riskLevel: RiskLevel;
  /** Factors that changed */
  changedFactors: string[];
  /** Scan timestamp */
  timestamp: number;
}

/**
 * Alert data
 */
export interface RiskAlert {
  /** Alert ID */
  id: string;
  /** Wallet address */
  wallet: PublicKey;
  /** Alert type */
  type: AlertType;
  /** Severity */
  severity: AlertSeverity;
  /** Message */
  message: string;
  /** Risk score */
  riskScore: number;
  /** Timestamp */
  timestamp: number;
  /** Acknowledged */
  acknowledged: boolean;
}

/**
 * Alert types
 */
export enum AlertType {
  ScoreIncrease = 'score_increase',
  HighRisk = 'high_risk',
  CriticalRisk = 'critical_risk',
  SuspiciousActivity = 'suspicious_activity',
  ProviderFailure = 'provider_failure',
  ThresholdExceeded = 'threshold_exceeded',
}

/**
 * Alert severity
 */
export enum AlertSeverity {
  Low = 'low',
  Medium = 'medium',
  High = 'high',
  Critical = 'critical',
}

/**
 * Wallet risk data
 */
export interface WalletRiskData {
  /** Wallet address */
  wallet: PublicKey;
  /** Current risk score */
  riskScore: number;
  /** Risk level */
  riskLevel: RiskLevel;
  /** Last updated */
  lastUpdated: number;
  /** Scan history */
  history: ScoreHistoryEntry[];
}

/**
 * Score history entry
 */
interface ScoreHistoryEntry {
  score: number;
  level: RiskLevel;
  timestamp: number;
  reason: string;
}

/**
 * Provider response interface
 */
interface RiskProvider {
  name: string;
  checkRisk(wallet: PublicKey): Promise<ProviderRiskResult>;
}

interface ProviderRiskResult {
  riskScore: number;
  riskFactors: string[];
  confidence: number;
  metadata?: Record<string, unknown>;
}

/**
 * Risk Engine Service
 */
export class RiskEngineService {
  private config: RiskEngineConfig;
  private providers: RiskProvider[];
  private isRunning: boolean = false;
  private scanInterval: NodeJS.Timeout | null = null;
  private alertCallbacks: Set<(alert: RiskAlert) => void> = new Set();
  private cachedScores: Map<string, WalletRiskData> = new Map();
  private alerts: RiskAlert[] = [];

  /**
   * Create a new Risk Engine Service
   */
  constructor(config: RiskEngineConfig) {
    this.config = {
      scanIntervalMs: 60000, // 1 minute default
      batchSize: 100,
      scoreChangeThreshold: 5,
      alertThreshold: 70,
      providers: [],
      ...config,
    };
    this.providers = [];
  }

  /**
   * Add a risk provider
   */
  addProvider(provider: RiskProvider): void {
    this.providers.push(provider);
    console.log(`[RiskEngine] Added provider: ${provider.name}`);
  }

  /**
   * Start the monitoring service
   */
  start(): void {
    if (this.isRunning) {
      console.warn('[RiskEngine] Service already running');
      return;
    }

    this.isRunning = true;
    this.scanInterval = setInterval(
      () => this.scanLoop(),
      this.config.scanIntervalMs
    );

    console.log(`[RiskEngine] Service started (interval: ${this.config.scanIntervalMs}ms)`);

    // Run initial scan
    this.scanLoop();
  }

  /**
   * Stop the monitoring service
   */
  stop(): void {
    if (this.scanInterval) {
      clearInterval(this.scanInterval);
      this.scanInterval = null;
    }
    this.isRunning = false;
    console.log('[RiskEngine] Service stopped');
  }

  /**
   * Main scan loop
   */
  private async scanLoop(): Promise<void> {
    if (!this.isRunning) return;

    try {
      console.log('[RiskEngine] Running scan...');

      // Get all registered wallets
      const wallets = await this.getRegisteredWallets();

      // Process in batches
      for (let i = 0; i < wallets.length; i += this.config.batchSize) {
        const batch = wallets.slice(i, i + this.config.batchSize);
        await this.processBatch(batch);

        // Rate limiting between batches
        if (i + this.config.batchSize < wallets.length) {
          await this.delay(100);
        }
      }

      console.log(`[RiskEngine] Scan complete. Wallets: ${wallets.length}`);
    } catch (error) {
      console.error('[RiskEngine] Scan error:', error);
    }
  }

  /**
   * Process a batch of wallets
   */
  private async processBatch(wallets: PublicKey[]): Promise<ScanResult[]> {
    const results: ScanResult[] = [];

    for (const wallet of wallets) {
      try {
        const result = await this.scanWallet(wallet);
        if (result) {
          results.push(result);
        }
      } catch (error) {
        console.error(`[RiskEngine] Error scanning ${wallet.toString()}:`, error);
      }
    }

    return results;
  }

  /**
   * Scan a single wallet
   */
  async scanWallet(wallet: PublicKey): Promise<ScanResult | null> {
    // Get previous score
    const previousData = this.cachedScores.get(wallet.toString());
    const previousScore = previousData?.riskScore ?? 0;

    // Query all providers
    const providerResults = await this.queryProviders(wallet);

    // Calculate new score
    const newScore = this.aggregateScores(providerResults);

    // Determine risk level
    const riskLevel = this.determineRiskLevel(newScore);

    // Check for significant changes
    const scoreChange = Math.abs(newScore - previousScore);

    if (scoreChange >= this.config.scoreChangeThreshold || previousScore === 0) {
      // Update cache
      this.updateCache(wallet, newScore, riskLevel);

      // Check for alerts
      if (newScore >= this.config.alertThreshold) {
        this.generateAlerts(wallet, previousScore, newScore, riskLevel);
      }

      return {
        wallet,
        previousScore,
        newScore,
        scoreChange,
        riskLevel,
        changedFactors: this.getChangedFactors(providerResults),
        timestamp: Date.now(),
      };
    }

    return null;
  }

  /**
   * Query all configured providers
   */
  private async queryProviders(wallet: PublicKey): Promise<ProviderRiskResult[]> {
    const results: ProviderRiskResult[] = [];

    for (const provider of this.providers) {
      try {
        const result = await provider.checkRisk(wallet);
        results.push(result);
      } catch (error) {
        console.error(`[RiskEngine] Provider ${provider.name} error:`, error);

        // Generate alert for provider failure
        this.generateProviderFailureAlert(provider.name, wallet);
      }
    }

    return results;
  }

  /**
   * Aggregate scores from multiple providers
   */
  private aggregateScores(results: ProviderRiskResult[]): number {
    if (results.length === 0) return 0;

    let totalWeight = 0;
    let weightedSum = 0;

    for (const result of results) {
      const weight = 100; // Default weight
      weightedSum += result.riskScore * weight;
      totalWeight += weight;
    }

    return Math.round(weightedSum / totalWeight);
  }

  /**
   * Determine risk level from score
   */
  private determineRiskLevel(score: number): RiskLevel {
    if (score < 25) return RiskLevel.Low;
    if (score < 50) return RiskLevel.Medium;
    if (score < 75) return RiskLevel.High;
    return RiskLevel.Critical;
  }

  /**
   * Get changed factors since last scan
   */
  private getChangedFactors(results: ProviderRiskResult[]): string[] {
    const allFactors = new Set<string>();

    for (const result of results) {
      for (const factor of result.riskFactors) {
        allFactors.add(factor);
      }
    }

    return Array.from(allFactors);
  }

  /**
   * Update cache with new score
   */
  private updateCache(wallet: PublicKey, score: number, level: RiskLevel): void {
    const key = wallet.toString();
    const existing = this.cachedScores.get(key);

    const history: ScoreHistoryEntry[] = existing?.history ?? [];

    // Add new entry
    history.push({
      score,
      level,
      timestamp: Date.now(),
      reason: 'Scheduled scan',
    });

    // Keep only last 100 entries
    if (history.length > 100) {
      history.shift();
    }

    this.cachedScores.set(key, {
      wallet,
      riskScore: score,
      riskLevel: level,
      lastUpdated: Date.now(),
      history,
    });
  }

  /**
   * Generate alerts for risk changes
   */
  private generateAlerts(
    wallet: PublicKey,
    previousScore: number,
    newScore: number,
    level: RiskLevel
  ): void {
    // High risk alert
    if (level === RiskLevel.High || level === RiskLevel.Critical) {
      const alert = this.createAlert(
        wallet,
        level === RiskLevel.Critical ? AlertType.CriticalRisk : AlertType.HighRisk,
        level === RiskLevel.Critical ? AlertSeverity.Critical : AlertSeverity.High,
        `${level} risk detected: Score ${newScore}`,
        newScore
      );
      this.alerts.push(alert);
      this.notifyAlertCallbacks(alert);
    }

    // Score increase alert
    if (newScore > previousScore && newScore - previousScore > 20) {
      const alert = this.createAlert(
        wallet,
        AlertType.ScoreIncrease,
        AlertSeverity.Medium,
        `Significant score increase: ${previousScore} → ${newScore}`,
        newScore
      );
      this.alerts.push(alert);
      this.notifyAlertCallbacks(alert);
    }
  }

  /**
   * Generate provider failure alert
   */
  private generateProviderFailureAlert(providerName: string, wallet: PublicKey): void {
    const alert = this.createAlert(
      wallet,
      AlertType.ProviderFailure,
      AlertSeverity.Low,
      `Provider ${providerName} failed to respond`,
      0
    );
    this.alerts.push(alert);
    this.notifyAlertCallbacks(alert);
  }

  /**
   * Create an alert
   */
  private createAlert(
    wallet: PublicKey,
    type: AlertType,
    severity: AlertSeverity,
    message: string,
    riskScore: number
  ): RiskAlert {
    return {
      id: `alert_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      wallet,
      type,
      severity,
      message,
      riskScore,
      timestamp: Date.now(),
      acknowledged: false,
    };
  }

  /**
   * Subscribe to alerts
   */
  onAlert(callback: (alert: RiskAlert) => void): () => void {
    this.alertCallbacks.add(callback);
    return () => this.alertCallbacks.delete(callback);
  }

  /**
   * Notify alert subscribers
   */
  private notifyAlertCallbacks(alert: RiskAlert): void {
    for (const callback of this.alertCallbacks) {
      try {
        callback(alert);
      } catch (error) {
        console.error('[RiskEngine] Alert callback error:', error);
      }
    }
  }

  /**
   * Get registered wallets from chain
   */
  private async getRegisteredWallets(): Promise<PublicKey[]> {
    // In production, this would query the blockchain for all KYC accounts
    // For now, return empty array
    console.log('[RiskEngine] Getting registered wallets...');
    return [];
  }

  /**
   * Get risk data for a wallet
   */
  getRiskData(wallet: PublicKey): WalletRiskData | undefined {
    return this.cachedScores.get(wallet.toString());
  }

  /**
   * Get all alerts
   */
  getAlerts(limit: number = 50): RiskAlert[] {
    return this.alerts.slice(-limit).reverse();
  }

  /**
   * Get unacknowledged alerts
   */
  getUnacknowledgedAlerts(): RiskAlert[] {
    return this.alerts.filter(a => !a.acknowledged);
  }

  /**
   * Acknowledge an alert
   */
  acknowledgeAlert(alertId: string): boolean {
    const alert = this.alerts.find(a => a.id === alertId);
    if (alert) {
      alert.acknowledged = true;
      return true;
    }
    return false;
  }

  /**
   * Get service statistics
   */
  getStats(): {
    isRunning: boolean;
    cachedWallets: number;
    totalAlerts: number;
    unacknowledgedAlerts: number;
    providers: number;
  } {
    return {
      isRunning: this.isRunning,
      cachedWallets: this.cachedScores.size,
      totalAlerts: this.alerts.length,
      unacknowledgedAlerts: this.alerts.filter(a => !a.acknowledged).length,
      providers: this.providers.length,
    };
  }

  /**
   * Force a scan of a specific wallet
   */
  async forceScan(wallet: PublicKey): Promise<ScanResult | null> {
    console.log(`[RiskEngine] Force scanning ${wallet.toString()}`);
    return this.scanWallet(wallet);
  }

  /**
   * Get risk trend for a wallet
   */
  getRiskTrend(wallet: PublicKey): {
    trend: 'increasing' | 'decreasing' | 'stable';
    change: number;
    historyLength: number;
  } {
    const data = this.cachedScores.get(wallet.toString());
    if (!data || data.history.length < 2) {
      return { trend: 'stable', change: 0, historyLength: data?.history.length ?? 0 };
    }

    const recent = data.history.slice(-5);
    const older = data.history.slice(0, Math.min(5, recent.length));

    const recentAvg = recent.reduce((sum, e) => sum + e.score, 0) / recent.length;
    const olderAvg = older.reduce((sum, e) => sum + e.score, 0) / older.length;

    const change = recentAvg - olderAvg;

    let trend: 'increasing' | 'decreasing' | 'stable';
    if (change > 5) trend = 'increasing';
    else if (change < -5) trend = 'decreasing';
    else trend = 'stable';

    return { trend, change: Math.round(change), historyLength: data.history.length };
  }

  /**
   * Utility delay function
   */
  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

/**
 * Create a default risk engine service
 */
export function createRiskEngineService(
  connection: Connection,
  kycProgramId: string,
  riskProgramId?: string
): RiskEngineService {
  return new RiskEngineService({
    connection,
    kycProgramId: new PublicKey(kycProgramId),
    riskProgramId: new PublicKey(riskProgramId ?? kycProgramId),
    scanIntervalMs: 60000,
    batchSize: 100,
    scoreChangeThreshold: 5,
    alertThreshold: 70,
    providers: [],
  });
}
